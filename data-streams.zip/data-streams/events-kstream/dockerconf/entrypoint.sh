#!/usr/bin/dumb-init /bin/sh

init_kafka_conf() {

    # Logging certs
    echo "User Key"

    # Starting Job
    echo "Started[Kafka Certificate Generation Process]"
    echo -e "${KAFKA_CA_CERT}" > /tmp/ca.crt
    echo -e "${KAFKA_USER_CERT}" > /tmp/user.crt
    echo -e "${KAFKA_USER_KEY}" > /tmp/user.key
    KEYSTORE_P12_PATH="/tmp/keystore.p12"
    TRUSTSTORE_JKS_PATH="/tmp/truststore.jks"
    KEYSTORE_JKS_PATH="/tmp/keystore.jks"


    # generate the keystore
    keytool -keystore "${TRUSTSTORE_JKS_PATH}" -storepass "${KAFKA_TRUSTSTORE_PASSWORD}" -alias CARoot -importcert -file /tmp/ca.crt -noprompt

    # Run the openssl command
    openssl pkcs12 -export -in /tmp/user.crt -inkey /tmp/user.key -name "${HOSTNAME}" -password pass:"${KAFKA_KEYSTORE_PASSWORD}" -out "${KEYSTORE_P12_PATH}"

    # Run the keytool command
    keytool -importkeystore -srckeystore "${KEYSTORE_P12_PATH}" -srcstoretype pkcs12 -srcalias "${HOSTNAME}" -destkeystore "${KEYSTORE_JKS_PATH}" -deststoretype jks -deststorepass "${KAFKA_KEYSTORE_PASSWORD}" -destalias "${HOSTNAME}" -srcstorepass "${KAFKA_KEYSTORE_PASSWORD}"

    # Delete the files
    rm -f /tmp/ca.crt /tmp/user.crt /tmp/user.key /tmp/keystore.p12

    echo "Done[Kafka Certificate Generation Process]"

}

start_app() {
    echo "Starting Events KStream App"
    java  -javaagent:/app/events-kstream/jmx_prometheus_javaagent.jar=8080:/app/events-kstream/jmx-exporter-config.yml -cp /app/events-kstream/events-kstream.jar com.sanni.streams."${MAIN_CLASS}"
}

init_kafka_conf
start_app
