package com.sanni.streams.models

import org.apache.kafka.streams.KeyValue
import org.apache.kafka.streams.kstream.Transformer
import org.apache.kafka.streams.processor.{Cancellable, ProcessorContext, PunctuationType}
import org.apache.kafka.streams.state.KeyValueStore
import org.json4s.{DefaultFormats, Formats}
import org.json4s.jackson.Serialization.write

import java.time.Duration
import java.util.Objects

class PaymentTransformer(StoreName: String) extends Transformer[String, String, KeyValue[String, String]] {

  private var keyValueStore: KeyValueStore[String, String] = null
  private var scheduledPunctuator: Cancellable = null
  private val stateStoreName: String = StoreName
  private var processorContext: ProcessorContext = null
  implicit val formats: Formats = DefaultFormats.preservingEmptyValues

  override def init(context: ProcessorContext): Unit = {
    this.processorContext = context
    this.keyValueStore = processorContext.getStateStore(stateStoreName).asInstanceOf[KeyValueStore[String, String]]
    this.scheduledPunctuator = processorContext.schedule(Duration.ofSeconds(5), PunctuationType.WALL_CLOCK_TIME, this.doPunctuate(_))
  }

  override def transform(key: String, value: String): KeyValue[String, String] = {
    var itemValueFromStore: String = keyValueStore.get(key) // payments
    if (Objects.isNull(itemValueFromStore)) {
      itemValueFromStore = value
    } else {
      itemValueFromStore = itemValueFromStore +"#"+ value
    }
    val data = itemValueFromStore.split("#")
    if (data.length >= 1000) {
      for (item <- data) {
        processorContext.forward(key, write(item))
      }
      keyValueStore.put(key, null)
    } else {
      keyValueStore.put(key, itemValueFromStore)
    }
    null
  }

  private def doPunctuate(timestamp: Long): Unit = {
    val valuesIterator = keyValueStore.all()
    while (valuesIterator.hasNext) {
      val keyValue = valuesIterator.next
      if (Objects.nonNull(keyValue.value)) {
        for (item <- keyValue.value.split("#")) {
          processorContext.forward(keyValue.key, write(item))
        }
        keyValueStore.put(keyValue.key, null)
      }
    }
  }

  override def close(): Unit = {
    scheduledPunctuator.cancel()
  }
}


