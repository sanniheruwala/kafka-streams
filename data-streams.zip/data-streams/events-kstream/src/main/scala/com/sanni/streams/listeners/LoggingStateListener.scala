package com.sanni.streams.listeners

import org.apache.kafka.streams.KafkaStreams
import org.apache.kafka.streams.KafkaStreams._
import org.slf4j.LoggerFactory

class LoggingStateListener(app: KafkaStreams) extends StateListener {

  private val LOGGER = LoggerFactory.getLogger(classOf[LoggingStateListener])

  override def onChange(newState: State, oldState: State): Unit = {
    LOGGER.info(s"Transitioning from [${oldState}] => [${newState}]")

    if ((newState eq KafkaStreams.State.RUNNING) && (oldState eq KafkaStreams.State.REBALANCING)) {
      LOGGER.info("Application has gone from [REBALANCING] to [RUNNING] ")
      LOGGER.info(s"Thread metadata [${app.localThreadsMetadata}]")
    }

    if (newState eq KafkaStreams.State.REBALANCING)
      LOGGER.info("Application is entering [REBALANCING] phase")
  }

}
