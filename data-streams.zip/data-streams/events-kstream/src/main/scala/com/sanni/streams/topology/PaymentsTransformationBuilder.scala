package com.sanni.streams.topology

import com.sanni.streams.config._
import com.sanni.streams.models.PaymentTransformer
import com.sanni.streams.serde.JSONDeserializer
import com.sanni.streams.config.{DBConfig, KafkaConfig}
import com.sanni.streams.models.{Connection, PaymentTransformer, RDBMSClient, inputData}
import org.apache.kafka.streams.scala.ImplicitConversions._
import org.apache.kafka.streams.scala.Serdes._
import org.apache.kafka.streams.scala.StreamsBuilder
import org.apache.kafka.streams.state.Stores
import org.json4s.jackson.Serialization.write
import org.json4s.native.JsonMethods.parse
import org.json4s.{DefaultFormats, Formats}
import scalikejdbc._

//case class MultipleValues(values: List[String])

class PaymentsTransformationBuilder()(
  implicit config: KafkaConfig, dbConfig: DBConfig
) extends BaseTopology {

  implicit val formats: Formats = DefaultFormats.preservingEmptyValues

  val allowedTables = "payments"

  override def init(): StreamsBuilder = {

    val builder: StreamsBuilder = new StreamsBuilder
    //    val inputStream: KStream[String, String] =
    //      builder.stream[String, String](config.topic.input)
    //        .map((k, v) => (k, parse(v).extract[inputData]))
    //        .map((_, v) => (v.table, v.data))
    //        .filter((k, _) => k == allowedTables)
    //        .map((_, v) => (v("id").toString, v))
    //        .map((k, v) => (write(k), write(DeNorm(v))))

    //    val inputStream =
    //      builder.stream[String, String](config.topic.input)
    //        .map((k, v) => (k, parse(v).extract[inputData]))
    //        .map((_, v) => (v.table, write(v.data)))
    //        .filter((k, _) => k == allowedTables)
    //        .groupByKey
    //        .windowedBy(TimeWindows.of(Duration.ofMillis(5000)))
    //        .reduce((k, v) => k + v)
    //        .toStream
    //        .map((windowedId, value) => (windowedId.key(), value))
    //        .foreach((k,v)=>println(k,v))

    val storeName = "multipleValuesStore"

    import org.apache.kafka.common.serialization.Serdes

//    val multipleValuesSerge = Serdes.serdeFrom(new JSONSerializer[MultipleValues], new JSONDeserializer[MultipleValues])

    val storeBuilder = Stores.
      keyValueStoreBuilder(Stores.persistentKeyValueStore(storeName), Serdes.String(), Serdes.String()).
      withCachingEnabled

    builder.addStateStore(storeBuilder)

    val inputStream =
      builder.stream[String, String](config.topic.input)
        .map((k, v) => (write(parse(v).extract[inputData].table), write(parse(v).extract[inputData].data)))
        .filter((k, v) => k == allowedTables)
        .transform(() => new PaymentTransformer(storeBuilder.name()), storeBuilder.name())
        .foreach((k, v) => println(k, v))


    //            inputStream.to(config.topic.output)

    builder
  }

  def DeNorm(data: Map[String, Any]): Map[String, Any] = {
    val cardId = data("card_id").toString
    val merchantId = data("merchant_id").toString
    val id = data("id").toString
    val orderId = data("order_id").toString
    val invoiceId = data("invoice_id")

    var results: Map[String, Any] = getResults(cardId, merchantId, id, orderId, invoiceId)

    results = results + ("payments_id" -> data("id")) +
      ("payments_auth_type" -> data("auth_type")) +
      ("payments_authentication_gateway" -> data("authentication_gateway")) +
      ("payments_authorized_at" -> data("authorized_at")) +
      ("payments_bank" -> data("bank")) +
      ("payments_base_amount" -> data("base_amount")) +
      ("payments_base_amount_refunded" -> data("base_amount_refunded")) +
      ("payments_captured_at" -> data("captured_at")) +
      ("payments_contact" -> data("contact")) +
      ("payments_cps_route" -> data("cps_route")) +
      ("payments_created_at" -> data("created_at")) +
      ("payments_email" -> data("email")) +
      ("payments_error_code" -> data("error_code")) +
      ("payments_error_description" -> data("error_description")) +
      ("payments_fee" -> data("fee")) +
      ("payments_gateway" -> data("gateway")) +
      ("payments_global_token_id" -> data("global_token_id")) +
      ("payments_internal_error_code" -> data("internal_error_code")) +
      ("payments_international" -> data("international")) +
      ("payments_invoice_id" -> data("invoice_id")) +
      ("payments_late_authorized" -> data("late_authorized")) +
      ("payments_merchant_id" -> data("merchant_id")) +
      ("payments_method" -> data("method")) +
      ("payments_order_id" -> data("order_id")) +
      ("payments_recurring" -> data("recurring")) +
      ("payments_recurring_type" -> data("recurring_type")) +
      ("payments_refund_status" -> data("refund_status")) +
      ("payments_status" -> data("status")) +
      ("payments_subscription_id" -> data("subscription_id")) +
      ("payments_terminal_id" -> data("terminal_id")) +
      ("payments_token_id" -> data("token_id")) +
      ("payments_updated_at" -> data("updated_at")) +
      ("payments_vpa" -> data("vpa")) +
      ("payments_wallet" -> data("wallet"))

    results
  }

  def toMap(rs: WrappedResultSet): Map[String, Any] = {
    (1 to rs.metaData.getColumnCount).foldLeft(Map[String, Any]()) { (result, i) =>
      val label = rs.metaData.getColumnLabel(i)
      Some(rs.any(label)).map { nullableValue => result + (label -> nullableValue) }.getOrElse(result)
    }
  }

  def getResults(card_id: String, merchant_id: String, id: String, order_id: String, invoice_id: Any): Map[String, Any] = {
    val startTime = System.currentTimeMillis()
    implicit val connection: Connection = RDBMSClient.resolveConnection("lookup")
    var invoice_id_str = ""
    if (invoice_id == null) {
      invoice_id_str = "null"
    } else {
      invoice_id_str = f"'${invoice_id.toString}'"
    }

    val CardIinsQuery: SQL[Nothing, NoExtractor] = sql"${
      sqls.createUnsafely(
        f"""
          select
          c.expiry_month as cards_expiry_month,c.expiry_year as cards_expiry_year,c.iin as cards_iin,c.issuer as cards_issuer,c.last4 as cards_last4,c.name as cards_name,c.network as cards_network,c.type as cards_type,
          i.country as iins_country,i.network as iins_network,i.type as iins_type
          from cards as c
          left join iins as i on c.iin = i.iin
          where c.id = '${card_id}'"""
      )
    }"

    val CardIinsRes: Option[Map[String, Any]] = connection.conn.toDB() readOnly { implicit session =>
      CardIinsQuery.map(toMap).single().apply()
    }

    val MerchantQuery: SQL[Nothing, NoExtractor] = sql"${
      sqls.createUnsafely(
        f"""
          select
          m.category as merchants_category,m.category2 as merchants_category2,m.name as merchants_name,m.website as merchants_website
          from merchants as m where m.id = '${merchant_id}'"""
      )
    }"

    val MerchantRes: Option[Map[String, Any]] = connection.conn.toDB() readOnly { implicit session =>
      MerchantQuery.map(toMap).single().apply()
    }

    val PaGeoQuery: SQL[Nothing, NoExtractor] = sql"${
      sqls.createUnsafely(
        f"""
          select
          pa.attempts as payment_analytics_attempts,pa.browser as payment_analytics_browser,pa.browser_version as payment_analytics_browser_version,pa.checkout_id as payment_analytics_checkout_id,pa.device as payment_analytics_device,pa.ip as payment_analytics_ip,pa.library as payment_analytics_library,pa.os as payment_analytics_os,pa.platform as payment_analytics_platform,pa.platform_version as payment_analytics_platform_version,pa.referer as payment_analytics_referer,
          gi.city as geo_ips_city, gi.state as geo_ips_state,gi.postal as geo_ips_postal,gi.country as geo_ips_country,gi.continent as geo_ips_continent,gi.latitude as geo_ips_latitude,gi.longitude as geo_ips_longitude,gi.isp as geo_ips_isp
          from payment_analytics as pa
          left join geo_ips as gi on pa.ip = gi.ip
          where pa.payment_id = '${id}'"""
      )
    }"

    val PaGeoRes: Option[Map[String, Any]] = connection.conn.toDB() readOnly { implicit session =>
      PaGeoQuery.map(toMap).single().apply()
    }

    val OrdersQuery: SQL[Nothing, NoExtractor] = sql"${
      sqls.createUnsafely(
        f"""
          select o.receipt as orders_receipt
          from orders as o where o.id = '${order_id}'"""
      )
    }"

    val OrdersRes: Option[Map[String, Any]] = connection.conn.toDB() readOnly { implicit session =>
      OrdersQuery.map(toMap).single().apply()
    }

    val InvoiceQuery: SQL[Nothing, NoExtractor] = sql"${
      sqls.createUnsafely(
        f"""
          select ii.type as invoices_type
          from invoices as ii where ii.id = ${invoice_id_str}"""
      )
    }"

    val InvoiceRes: Option[Map[String, Any]] = connection.conn.toDB() readOnly { implicit session =>
      InvoiceQuery.map(toMap).single().apply()
    }

    val InvoiceDefault = Map("invoices_type" -> null)

    val RiskQuery: SQL[Nothing, NoExtractor] = sql"${
      sqls.createUnsafely(
        f"""
          select r.reason as risk_reason,r.source as risk_source
          from risk as r where r.payment_id = '${id}' or r.source = null"""
      )
    }"

    val RiskRes: Option[Map[String, Any]] = connection.conn.toDB() readOnly { implicit session =>
      RiskQuery.map(toMap).single().apply()
    }

    val RiskDefault = Map("risk_reason" -> null, "risk_source" -> null)

    val UpiQuery: SQL[Nothing, NoExtractor] = sql"${
      sqls.createUnsafely(
        f"""
          select u.acquirer as upi_acquirer,u.bank as upi_bank,u.provider as upi_provider,u.type as upi_type
          from upi as u where u.payment_id = '${id}'"""
      )
    }"

    val UpiDefault = Map("upi_acquirer" -> null, "upi_bank" -> null, "upi_provider" -> null, "upi_type" -> null)

    val UpiRes: Option[Map[String, Any]] = connection.conn.toDB() readOnly { implicit session =>
      UpiQuery.map(toMap).single().apply()
    }

    val res = CardIinsRes.get.++(MerchantRes.get).++(PaGeoRes.get).++(OrdersRes.get)
      .++(InvoiceRes.getOrElse(InvoiceDefault)).++(RiskRes.getOrElse(RiskDefault)).++(UpiRes.getOrElse(UpiDefault))
    logger.info("received data : " + write(Map("message" -> "KSTREAM_DB_LOOKUP_TIME", "id" -> id, "time_taken" -> (System.currentTimeMillis() - startTime), "lookup_data" -> res)))

    res
    //    val query: SQL[Nothing, NoExtractor] = sql"${
    //      sqls.createUnsafely(
    //        f"""
    //          select
    //          c.expiry_month as cards_expiry_month,c.expiry_year as cards_expiry_year,c.iin as cards_iin,c.issuer as cards_issuer,c.last4 as cards_last4,c.name as cards_name,c.network as cards_network,c.type as cards_type,
    //          i.country as iins_country,i.network as iins_network,i.type as iins_type,
    //          gi.city as geo_ips_city, gi.state as geo_ips_state,gi.postal as geo_ips_postal,gi.country as geo_ips_country,gi.continent as geo_ips_continent,gi.latitude as geo_ips_latitude,gi.longitude as geo_ips_longitude,gi.isp as geo_ips_isp,
    //          ii.type as invoices_type,
    //          m.category as merchants_category,m.category2 as merchants_category2,m.name as merchants_name,m.website as merchants_website,
    //          o.receipt as orders_receipt,
    //          r.reason as risk_reason,r.source as risk_source,
    //          u.acquirer as upi_acquirer,u.bank as upi_bank,u.provider as upi_provider,u.type as upi_type,
    //          pa.attempts as payment_analytics_attempts,pa.browser as payment_analytics_browser,pa.browser_version as payment_analytics_browser_version,pa.checkout_id as payment_analytics_checkout_id,pa.device as payment_analytics_device,pa.ip as payment_analytics_ip,pa.library as payment_analytics_library,pa.os as payment_analytics_os,pa.platform as payment_analytics_platform,pa.platform_version as payment_analytics_platform_version,pa.referer as payment_analytics_referer
    //          from cards as c
    //          left join iins as i on c.iin = i.iin
    //          left join merchants as m on m.id = '${merchant_id}'
    //          left join payment_analytics as pa on pa.payment_id = '${id}'
    //          left join orders as o on o.id = '${order_id}'
    //          left join invoices as ii on ii.id =  ${invoice_id_str}
    //          left join geo_ips as gi on pa.ip = gi.ip
    //          left join risk as r on r.payment_id = '${id}' or r.source = null
    //          left join upi as u on u.payment_id = '${id}'
    //          where c.id = '${card_id}'"""
    //      )
    //    }"
  }
}
