package com.sanni.streams.topology

import java.sql.SQLException
import com.sanni.streams.config._
import com.sanni.streams.exceptions.{ApplicableColumnsNotDefined, InvalidOpTypeException}
import com.sanni.streams.models._
import com.sanni.streams.config.{DBConfig, KafkaConfig}
import com.sanni.streams.exceptions.{ApplicableColumnsNotDefined, InvalidOpTypeException}
import com.sanni.streams.helpers.JsonUtil
import com.sanni.streams.models.{Connection, DebeziumPostgresRecord, DebeziumSource, MaxwellDmlRecord, RDBMSClient}
import com.sanni.streams.serde.JSONSerde
import org.apache.kafka.common.serialization.Serdes
import org.apache.kafka.streams.kstream.Produced
import org.apache.kafka.streams.scala.ImplicitConversions._
import org.apache.kafka.streams.scala.kstream.{KStream, KTable}
import org.apache.kafka.streams.scala.Serdes._
import org.apache.kafka.streams.scala.StreamsBuilder
import org.apache.logging.log4j.LogManager
import org.json4s.{DefaultFormats, Formats}
import org.json4s.jackson.Serialization.write
import org.json4s.native.JsonMethods.parse
import org.json4s.ParserUtil.ParseException
import org.postgresql.util.{PGobject, PSQLException}
import scalikejdbc._

class PaymentsCardTransformationBuilder()(
  implicit config: KafkaConfig, dbConfig: DBConfig
) extends BaseTopology {

  val checkUpdateRequiredTables = List[String](
      "transactions",
      "payment_meta"
  )

  // List of tables for kstream will process records
  val allowedTables = List[String]("payments") ++ checkUpdateRequiredTables

  implicit val formats: Formats = DefaultFormats.preservingEmptyValues

  def convertDebeziumPostgresRecordToMaxwellRecord(
      key: Map[String, Any],
      record: DebeziumPostgresRecord
  ): (Map[String, Any], MaxwellDmlRecord) = {
    val recordKeys = Map[String, Any](
      "database" -> record.source.db,
      "table" -> record.source.table
    ) ++ key.map(k => s"pk.${k._1}" -> k._2)

    (recordKeys, MaxwellDmlRecord(
      record.source.db,
      record.source.table,
      resolveToStandardOpType(record.op),
      record.ts_ms,
      0L,
      true,
      s"postgres:${record.source.lsn}",
      Some(Array[String]("id")),
      getData(record),
      record.before
    ))
  }

  override def init(): StreamsBuilder = {
    val builder: StreamsBuilder = new StreamsBuilder
    val inputStream: KStream[String, String] =
      builder.stream[String, String](
        Set[String](config.topic.input, config.topic.metadata)
      )

    val forks: Array[KStream[Map[String, Any], (Boolean, DebeziumPostgresRecord)]] =
    inputStream.map((key: String, value: String) => {
      val pkData: Map[String, Any] = if (key == null) {
        Map[String, Any]()
      } else {
        parse(key).extract[Map[String, Any]]
      }
      (key, value)

      val record = parse(value).extract[DebeziumPostgresRecord]
      (pkData, record)
    }).filter((key: Map[String, Any], value: DebeziumPostgresRecord) => {
        allowedTables.contains(value.source.table) &&
        checkIfPaymentsRecordRequired(value, getData(value), value.source.table)
    }).map((key: Map[String, Any], value: DebeziumPostgresRecord) => {
      (key, processDebeziumEvent(value))
    }).branch(
      // Branch in which entity has been transformed to api.payments
      (key: Map[String, Any], value: (Boolean, DebeziumPostgresRecord)) => value._1,
      // Branch in which payments entity for a given payment_id doesn't exist in replica yet
      (key: Map[String, Any], value: (Boolean, DebeziumPostgresRecord)) => !value._1,
    )

    forks(0).map(
      (key: Map[String, Any], value: (Boolean, DebeziumPostgresRecord)) => {
        val (recordKey: Map[String, Any], maxwellRecord: MaxwellDmlRecord) = convertDebeziumPostgresRecordToMaxwellRecord(
          key, value._2
        )
        (write(recordKey), write(maxwellRecord))
      }
    ).to(config.topic.output)

    // Push the records for which payments doesn't exist in replica to another topic
    // So that the record is again processed when the record becomes available in replica
    forks(1).map(
      (key: Map[String, Any], value: (Boolean, DebeziumPostgresRecord)) => {
        (write(key), write(value._2))
      }
    ).to(config.topic.metadata)

    builder
  }

  /**
   * List of columns for each table which are needed in api.payments entity
   * @param table Table name for which api payments columns are required
   */
  def getTableApplicableColumn(table: String): List[String] = {
    table match {
      case "transactions" => List[String](
        "transaction_id", "payment_id", "fee", "mdr", "tax"
      )
      case "payment_meta" => List[String]("convert_currency")
      case _ => throw new ApplicableColumnsNotDefined(s"Columns not applicable for table $table")
    }
  }

  def getData(record: DebeziumPostgresRecord): Map[String, Any] = {
    if (record.after.isDefined) {
      record.after.get
    } else {
      record.before.get
    }
  }

  def resolveToStandardOpType(opType: String): String = {
    opType match {
      case "c" => "insert"
      case "u" => "update"
      case "d" => "delete"
      case _   => throw new InvalidOpTypeException(s"OpType $opType in the record is not valid")
    }
  }

  def processDebeziumEvent(dbEvent: DebeziumPostgresRecord): (Boolean, DebeziumPostgresRecord) = {
      val table = dbEvent.source.table
      val tableMapData = getData(dbEvent)
      val paymentId = tableMapData("payment_id").toString()
      val (shouldTransform: Boolean, recordMap: Map[String, Any]) = table match {
          case "payments" => ( true, createApiPaymentsRecordFromPayments(dbEvent, tableMapData) ++ processTransactionsTable(dbEvent, paymentId) ++ processPaymentMetaTable(dbEvent, paymentId))
          case "transactions" => {
            val paymentsRecord = processPaymentsTable(dbEvent, paymentId)
            if (paymentsRecord.isDefined) {
              (true, paymentsRecord.get ++ processPaymentMetaTable(dbEvent, paymentId) ++ createApiPaymentsRecordFromTransaction(dbEvent, tableMapData))
            } else {
              // Payment entity doesn't exist for given payment_id,
              // so the record is not mapped to api.payments table record
              (false, Map[String, Any]())
            }
          }
          case "payment_meta" => {
            val paymentsRecord = processPaymentsTable(dbEvent, paymentId)
            if (paymentsRecord.isDefined) {
              (true, paymentsRecord.get ++ processTransactionsTable(dbEvent, paymentId) ++ createApiPaymentsRecordFromPaymentMeta(dbEvent, tableMapData))
            } else {
              // Payment entity doesn't exist for given payment_id,
              // so the record is not mapped to api.payments table record
              (false, Map[String, Any]())
            }
          }
      }

      // If payments entity for given payment_id doesn't exist in replica,
      // return original debezium record with a flag indicating that
      // the record has not been transformed
      // because the payment entity doesn't exist for that payment_id yet
      if (shouldTransform) {
        val before = if (dbEvent.op == "c") None else Some(recordMap)
        val after = if (dbEvent.op == "d") None else Some(recordMap)
        (true, DebeziumPostgresRecord(
          before,
          after,
          dbEvent.op,
          dbEvent.ts_ms,
          DebeziumSource(
            dbEvent.source.version,
            dbEvent.source.connector,
            dbEvent.source.name,
            dbEvent.source.ts_ms,
            dbEvent.source.snapshot,
            "api",
            dbEvent.source.schema,
            "payments",
            dbEvent.source.txId,
            dbEvent.source.lsn,
            dbEvent.source.xmin
          ),
          dbEvent.transaction,
          dbEvent._record_source
        ))
      } else {
        (false, dbEvent)
      }
  }

  def toMap(rs: WrappedResultSet): Map[String, Any] =  {
    (1 to rs.metaData.getColumnCount).foldLeft(Map[String, Any]()) { (result, i) =>
      val label = rs.metaData.getColumnLabel(i)
      Some(rs.any(label)).map { nullableValue => result + (label -> nullableValue) }.getOrElse(result)
    }
  }

  /**
   * Fetch payments records for given payment_id from payments table
   */
  def processPaymentsTable(
    dbEvent: DebeziumPostgresRecord, paymentId: String
  )(implicit dbConfig: DBConfig): Option[Map[String, Any]] = {
    val paymentsCardPaymentsRecord: Option[Map[String, Any]]  = if (dbConfig.enabled) {
      implicit val connection: Connection = RDBMSClient.resolveConnection(dbEvent.source.db)
      val query: SQL[Nothing,NoExtractor] = sql"${sqls.createUnsafely(
        "select * from payments where payment_id = ? order by updated_at desc LIMIT 1",
        List[Any](paymentId)
      )}"
      runQuery(dbEvent.source.db, query)
    } else {
      logger.warn("DB query disabled for payments, not querying db")
      None
    }

    paymentsCardPaymentsRecord.flatMap(x =>
      Some(createApiPaymentsRecordFromPayments(
        dbEvent,
        x)
      )
    )
  }

  def runQuery(
    database: String, query: SQL[Nothing,NoExtractor]
  )(implicit connection: Connection): Option[Map[String, Any]] = {
    try {
      execQuery(query)
    } catch {
      case e:PSQLException =>
        if ((e.getMessage contains "The connection attempt failed")
            || (e.getMessage contains "Check that the hostname and port are correct")
            || (e.getMessage contains "FATAL")) {
          brokenDBConnection(database)
          runQuery(database, query)
        } else {
          throw e
        }
    }
  }

  def execQuery(query: SQL[Nothing, NoExtractor])(
    implicit connection: Connection
  ): Option[Map[String, Any]] = {
      connection.conn.toDB() readOnly { implicit session =>
        query.map(toMap).single().apply()
      }
  }

    /**
   * Called when DB can't be connected
   * Polls DB for connection finite number of times
   * Throws an exception if db connection fails even after retries
   */
  def brokenDBConnection(database: String): Unit = {
    // Retry loop of 60 attempts for connecting to DB
    // So the downtime of postgres supported would be 10 minutes.
    // After that the application will exit
    val dbConnected = List
      .fill(60)(false)
      .reduce(
        (x, _) => {
          if (x || isDBConnected(database)) {
            true
          } else {
            // Sleep for 10 secs before next retry
            logger.warn("DB not connected, waiting for 10 seconds before retrying")
            Thread.sleep(10000)
            false
          }
        }
      )

    if (dbConnected) {
      logger.warn("DB reconnected")
    } else {
      logger.error("FATAL: Can't connect to DB after retry attempts, exiting application.")
      throw new Exception("FATAL: DB connection failed")
    }
  }

  /**
  Checks whether sink DB is connected
   **/
  def isDBConnected(database: String): Boolean = {
    logger.warn("Checking DB connection")
    val validationQuery: String = "SELECT 1"
    try {
      implicit val connection: Connection = RDBMSClient.resolveConnection(database)
      execQuery(SQL(validationQuery))
      true
    } catch {
      case x:SQLException =>
        // Connection validation query failed to execute
        logger.error(x.getMessage)
        false
    }
  }

  def processTransactionsTable(
    dbEvent: DebeziumPostgresRecord, paymentId: String
  )(implicit dbConfig: DBConfig): Map[String, Any] = {
    val applicableColumns = getTableApplicableColumn("transactions")

    val selectColumns = sqls.csv(
      applicableColumns.map(
        x => sqls.createUnsafely(s"`$x`")
      ): _*
    )
    val table = dbEvent.source.table
    val paymentsCardPaymentsRecord: Option[Map[String, Any]] = if (dbConfig.enabled) {
      implicit val connection = RDBMSClient.resolveConnection(dbEvent.source.db)
      val query: SQL[Nothing,NoExtractor] = sql"${sqls.createUnsafely(
        s"select * from transactions where payment_id = ? order by updated_at desc limit 1",
        List[Any](paymentId)
      )}"
      runQuery(dbEvent.source.db, query)
    } else {
      logger.warn("DB query disabled for transactions, not querying db")
      None
    }

    createApiPaymentsRecordFromTransaction(
      dbEvent,
      paymentsCardPaymentsRecord.getOrElse(Map[String, Any]())
    )
  }

  def processPaymentMetaTable(
    dbEvent: DebeziumPostgresRecord, paymentId: String
  )(implicit dbConfig: DBConfig): Map[String, Any] = {
    val applicableColumns = getTableApplicableColumn("payment_meta")
    val table = dbEvent.source.table
    val paymentsCardPaymentsRecord: Option[Map[String, Any]] = if (dbConfig.enabled) {
      implicit val connection = RDBMSClient.resolveConnection(dbEvent.source.db)
      val query: SQL[Nothing,NoExtractor] = sql"${sqls.createUnsafely(
        "select * from payment_meta where payment_id = ? order by updated_at desc limit 1",
        List[Any](paymentId)
      )}"
      runQuery(dbEvent.source.db, query)
    } else {
      logger.warn("DB query disabled for payment_meta, not querying db")
      None
    }

    createApiPaymentsRecordFromPaymentMeta(
      dbEvent,
      paymentsCardPaymentsRecord.getOrElse(Map[String, Any]())
    )
  }

  def createApiPaymentsRecordFromPayments(
    dbEvent: DebeziumPostgresRecord,
    data: Map[String, Any],
  ): Map[String, Any] = {
    val baseMap = Map[String, Any](
      "id" -> data.getOrElse("payment_id", None),
      "merchant_id" -> data.getOrElse("merchant_id", None),
      "amount" -> data.getOrElse("amount", None),
      "currency" -> data.getOrElse("currency", None),
      "method" -> data.getOrElse("method", None),
      "status" -> data.getOrElse("status", None),
      "two_factor_auth" -> data.getOrElse("two_factor_auth", None),
      "order_id" -> data.getOrElse("order_id", None),
      "international" -> data.getOrElse("international", None),
      "description" -> data.getOrElse("description", None),
      "customer_id" -> data.getOrElse("customer_id", None),
      "global_customer_id" -> data.getOrElse("global_customer_id", None),
      "app_token" -> data.getOrElse("app_token", None),
      "token_id" -> data.getOrElse("token_id", None),
      "auth_type" -> data.getOrElse("auth_type", None),
      "acknowledged_at" -> data.getOrElse("acknowledged_at", None),
      "fee_bearer" -> data.getOrElse("fee_bearer", None),
      "global_token_id" -> data.getOrElse("global_token_id", None),
      "email" -> data.getOrElse("email", None),
      "contact" -> data.getOrElse("contact", None),
      "notes" -> data.getOrElse("notes", None),
      "auto_captured" -> fetchColumnWithDefaultValue(data, "auto_captured", 0),
      "gateway_captured" -> data.getOrElse("gateway_captured", None),
      "batch_id" -> data.getOrElse("batch_id", None),
      "signed" -> fetchColumnWithDefaultValue(data, "signed", 0),
      "verified" -> data.getOrElse("verified", None),
      "callback_url" -> data.getOrElse("callback_url", None),
      "late_authorized" -> data.getOrElse("late_authorized", None),
      "disputed" -> fetchColumnWithDefaultValue(data, "disputed", 0),
      "created_at" -> data.getOrElse("created_at", None),
      "updated_at" -> data.getOrElse("updated_at", None),
      "public_key" -> data.getOrElse("public_key", None),
      "amount_authorized" -> fetchColumnWithDefaultValue(data, "amount_authorized", 0),
      "authorized_at" -> data.getOrElse("authorized_at", None),
      "authentication_gateway" -> data.getOrElse("authentication_gateway", None),
      "authenticated_at" -> data.getOrElse("authenticated_at", None),
      "captured_at" -> data.getOrElse("captured_at", None),
      "amount_refunded" -> fetchColumnWithDefaultValue(data, "amount_refunded", 0),
      "refund_status" -> data.getOrElse("refund_status", None),
      "on_hold" -> data.getOrElse("on_hold", 0),
      "refund_at" -> data.getOrElse("refund_at", None),
      "settled_by" -> data.getOrElse("settled_by", None),
      "_record_source" -> "payments_card"
    )

    // Extract records from within json fields and map it to api.payments columns
    baseMap ++ extractFromCardsField(data("card")) ++
      extractFromProductField(data("product")) ++
      extractFromEmiField(data("emi")) ++ extractFromErrorField(data("error")) ++
      extractFromTerminalField(data("terminal")) ++
      extractFromGatewayReferenceField(data("gateway_reference")) ++
      extractFromTransactionTypeField(data("transaction_type"))
  }

  def fetchColumnWithDefaultValue(
    data: Map[String, Any], column: String, defaultValue: Any
  ): Any = {
    if (data.contains(column) && data(column) != null && data(column) != None) {
      data(column)
    } else {
      defaultValue
    }
  }

    /**
   * Fetches api.payments entity columns stored in payments_card.payment_meta table
   * which are mapped to api.payments
   * @param data authorization entity cdc event
   * @return Iterable of EntityRecord for api.payments table operation
   */
  def createApiPaymentsRecordFromPaymentMeta(
    dbEvent: DebeziumPostgresRecord,
    data: Map[String, Any],
  ): Map[String, Any] = {
    Map[String, Any](
      "convert_currency" -> data.getOrElse("convert_currency", None)
    )
  }

    /**
   * Fetches api.payments entity columns stored in payments_card.transaction table
   * which are mapped to api.payments
   * @param data authorization entity cdc event
   * @return Iterable of EntityRecord for api.payments table operation
   */
  def createApiPaymentsRecordFromTransaction(
    dbEvent: DebeziumPostgresRecord,
    data: Map[String, Any],
  ): Map[String, Any] = {
    Map[String, Any](
      "transaction_id" -> data.getOrElse("transaction_id", None),
      "fee" -> data.getOrElse("fee", None),
      "mdr" -> data.getOrElse("mdr", None),
      "tax" -> data.getOrElse("tax", None)
    )
  }

  /**
   * It checks whether for a given CDC event, payment entity needs to be updated or not
   * @param applicableColumns List of columns which are mapped to api.payments entity
   * @param data
   * @return
   */
  def checkIfPaymentsRecordRequired(
    dbEvent: DebeziumPostgresRecord,
    data: Map[String, Any],
    table: String
  ): Boolean = {
    if (!checkUpdateRequiredTables.contains(table)) {
      true
    } else {
      val applicableColumns = getTableApplicableColumn(table)
      val resolvedOptype = resolveToStandardOpType(dbEvent.op)
      // If record operation is insert, then a Update to api.payments is necessary
      if (dbEvent.source.table != table) {
        true
      } else if (resolvedOptype == "insert") {
        true
      } else if (resolvedOptype == "update" && dbEvent.before.isDefined) {
        // If record operation is update, then a Update to api.payments is required
        // only if the columns that are mapped to api.payments are updated
        applicableColumns.foldLeft[Boolean](false)((x, y) => {
          val beforeRecord = dbEvent.before.get
          x || (beforeRecord.getOrElse(y, None) != data.getOrElse(y, None))
        })
      } else {
        false
      }
    }
  }

  /**
   * Fetches payments entity columns stored in card json field from payments_card.payments
   * which are mapped to api.payments
   * @param data card json record from cdc event
   * @return Map of columns and its values that needs to be populated in api.payments
   */
  def extractFromCardsField(data: Any): Map[String, Any] = {
    def computeRecord(save: Any = 0, cardId: Any = None): Map[String, Any] = Map[String, Any](
      "save" -> save,
      "card_id" -> cardId
    )

    def processValidRecord(validData: String): Map[String, Any] = {
      val cardRecord = parse(validData).extract[Map[String, Any]]
        val cardId: Any = cardRecord.getOrElse("card_id", None) match {
          case id: String => id.stripPrefix("card_")
          case columnVale => columnVale
        }
        val save = cardRecord.getOrElse("save", 0) match {
          case None|null => 0
          case record => record
        }

        computeRecord(
          save = save,
          cardId = cardId
        )
    }
    data match {
      case data: String => processValidRecord(data)
      // On querying postgres, the datatype of json column returned is PGobject
      case data: PGobject => processValidRecord(data.getValue())
      case null | None => computeRecord()
    }
  }

  /**
   * Fetches payments entity columns stored in product json field from payments_card.payments
   * which are mapped to api.payments
   * @param data product json record from cdc event
   * @return Map of columns and its values that needs to be populated in api.payments
   */
  def extractFromProductField(data: Any): Map[String, Any] = {
    def computeRecord(
     invoiceId: Any = None,
     subscriptionId: Any = None,
     transferId: Any = None,
     paymentLinkId: Any = None
   ): Map[String, Any] = Map[String, Any](
      "invoice_id" -> invoiceId,
      "subscription_id" -> subscriptionId,
      "transfer_id" -> transferId,
      "payment_link_id" -> paymentLinkId
    )

    def processValidRecord(validData: String): Map[String, Any] = {
      val productRecord = parse(validData).extract[Map[String, Any]]
      productRecord.get("product_type") match {
        case None => computeRecord()
        case Some(typeData) => {
          typeData match {
            case "invoice" => computeRecord(
              invoiceId = productRecord.getOrElse("product_id", None)
            )
            case "subscription" => computeRecord(
              subscriptionId = productRecord.getOrElse("product_id", None)
            )
            case "transfer" => computeRecord(
              transferId = productRecord.getOrElse("product_id", None)
            )
            case "payment_link" => computeRecord(
              paymentLinkId = productRecord.getOrElse("product_id", None)
            )
            case _ => computeRecord()
          }
        }
      }
    }
    data match {
      case data: String => processValidRecord(data)
      // On querying postgres, the datatype of json column returned is PGobject
      case data: PGobject => processValidRecord(data.getValue())
      case null | None => computeRecord()
    }
  }

  /**
   * Fetches payments entity columns stored in emi json field from payments_card.payments
   * which are mapped to api.payments
   * @param data emi json record from cdc event
   * @return Map of columns and its values that needs to be populated in api.payments
   */
  def extractFromEmiField(data: Any): Map[String, Any] = {
    def computeRecord(
      emiPlanId: Any = None, emiSubvention: Any = None
    ): Map[String, Any] = Map[String, Any](
      "emi_plan_id" -> emiPlanId,
      "emi_subvention" -> emiSubvention
    )

    def processValidRecord(validData: String): Map[String, Any] = {
      val emiRecord: Map[String, Any] = parse(validData).extract[Map[String, Any]]
      computeRecord(
        emiPlanId = emiRecord.getOrElse("emi_plan_id", None),
        emiSubvention = emiRecord.getOrElse("subvention", None)
      )
    }
    data match {
      case data: String => processValidRecord(data)
      // On querying postgres, the datatype of json column returned is PGobject
      case data: PGobject => processValidRecord(data.getValue())
      case None| null => computeRecord()
    }
  }

  /**
   * Fetches payments entity columns stored in error json field from payments_card.payments
   * which are mapped to api.payments
   * @param data error json record from cdc event
   * @return Map of columns and its values that needs to be populated in api.payments
   */
  def extractFromErrorField(data: Any): Map[String, Any] = {
    def computeRecord(
        errorCode: Any = None,
        internalErrorCode: Any = None,
        errorDescription: Any = None,
        cancellationReason: Any = None
    ): Map[String, Any] = Map[String, Any](
      "error_code" -> errorCode,
      "internal_error_code" -> internalErrorCode,
      "error_description" -> errorDescription,
      "cancellation_reason" -> cancellationReason
    )

    def processValidRecord(validData: String): Map[String, Any] = {
        val errorRecord: Map[String, Any] = parse(validData).extract[Map[String, Any]]
        computeRecord(
          errorRecord.getOrElse("error_code", None),
          errorRecord.getOrElse("internal_error_code", None),
          errorRecord.getOrElse("error_description", None),
          errorRecord.getOrElse("cancellation_reason", None)
        )
    }
    data match {
      case data: String => processValidRecord(data)
      // On querying postgres, the datatype of json column returned is PGobject
      case data: PGobject => processValidRecord(data.getValue())
      case None| null => computeRecord()
    }
  }

  /**
   * Fetches payments entity columns stored in terminal json field from payments_card.payments
   * which are mapped to api.payments
   * @param data terminal json record from cdc event
   * @return Map of columns and its values that needs to be populated in api.payments
   */
  def extractFromTerminalField(data: Any): Map[String, Any] = {
    def computeRecord(gateway: Any = None, terminalId: Any = None): Map[String, Any] =
      Map[String, Any](
        "gateway" -> gateway,
        "terminal_id" -> terminalId
      )

    def processValidRecord(validData: String): Map[String, Any] = {
        val terminalRecord: Map[String, Any] = parse(validData).extract[Map[String, Any]]
        computeRecord(
          gateway = terminalRecord.getOrElse("gateway", None),
          terminalId = terminalRecord.getOrElse("terminal_id", None)
        )
    }
    data match {
      case data: String => processValidRecord(data)
      // On querying postgres, the datatype of json column returned is PGobject
      case data: PGobject => processValidRecord(data.getValue())
      case None| null => computeRecord()
    }
  }

  /**
   * Fetches payments entity columns stored in gateway_reference json field from payments_card.payments
   * which are mapped to api.payments
   * @param data gateway_reference json record from cdc event
   * @return Map of columns and its values that needs to be populated in api.payments
   */
  def extractFromGatewayReferenceField(data: Any): Map[String, Any] = {
    def computeRecord(authCode: Any = None): Map[String, Any] = Map[String, Any](
      "reference2" -> authCode
    )

    def processValidRecord(validData: String): Map[String, Any] = {
      val gatewayReferenceRecord: Map[String, Any] = parse(validData).extract[Map[String, Any]]
      computeRecord(
        authCode = gatewayReferenceRecord.getOrElse("auth_code", None)
      )
    }
    data match {
      case data: String => processValidRecord(data)
      // On querying postgres, the datatype of json column returned is PGobject
      case data: PGobject => processValidRecord(data.getValue())
      case None| null => computeRecord()
    }
  }

  /**
   * Fetches payments entity columns stored in transaction json field from payments_card.payments
   * which are mapped to api.payments
   * @param data transaction_type json record from cdc event
   * @return Map of columns and its values that needs to be populated in api.payments
   */
  def extractFromTransactionTypeField(data: Any): Map[String, Any] = {
    val allowedTransactionType = List[String]("recurring_auto", "recurring_initial")
    def computeRecord(
      recurring: Any = 0,
      recurringType: Any = None
    ): Map[String, Any] = Map[String, Any](
      "recurring" -> recurring,
      "recurring_type" -> recurringType
    )
    def processValidRecord(validData: String): Map[String, Any] = {
      val transactionTypeRecord: Map[String, Any] = parse(validData).extract[Map[String, Any]]
      val (recurring: Any, recurringType: Any) =
        transactionTypeRecord.getOrElse("type", None) match {
        case typeInfo: String => if (allowedTransactionType.contains(typeInfo)) {
          (1, typeInfo.stripPrefix("recurring_"))
        } else {
          (0, None)
        }
        case _ => (0, None)
      }
      computeRecord(
        recurring = recurring,
        recurringType = recurringType
      )
    }

    data match {
      case data: String => processValidRecord(data)
      // On querying postgres, the datatype of json column returned is PGobject
      case data: PGobject => processValidRecord(data.getValue())
      case None| null => computeRecord()
    }
  }


}
