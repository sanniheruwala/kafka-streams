package com.sanni.streams.exceptions

case class InvalidOpTypeException(
  message: String,
  cause: Throwable = None.orNull)
extends Exception(message, cause)
