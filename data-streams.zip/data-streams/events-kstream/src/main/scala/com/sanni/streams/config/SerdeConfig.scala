package com.sanni.streams.config

case class SerdeConfig(key: String, value: String)
