package com.sanni.streams.helpers

import com.fasterxml.jackson.annotation.JsonInclude.Include
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.node.{ArrayNode, ObjectNode}
import com.fasterxml.jackson.databind.util.JSONPObject
import com.fasterxml.jackson.databind.{DeserializationFeature, JsonNode, ObjectMapper}
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import com.fasterxml.jackson.module.scala.experimental.ScalaObjectMapper

/**
 * A Json utility to serialize/deserialize any object.
 * Reference: https://coderwall.com/p/o--apg/easy-json-un-marshalling-in-scala-with-jackson
 */
object JsonUtil {
  val mapper = new ObjectMapper() with ScalaObjectMapper
  mapper.registerModule(DefaultScalaModule)
  mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
  mapper.setSerializationInclusion(Include.NON_NULL)
  mapper.setSerializationInclusion(Include.NON_ABSENT)

  /**
   * Converts any object to respective JSON String
   *
   * @param value
   * @return
   */
  def toJson(value: Map[Symbol, Any]): String = {
    toJson(value map { case (k, v) => k.name -> v })
  }

  /**
   * Converts Map[String,Any] to Map[String, String] for serialization use cases
   *
   * @param map => Map[String, Any] (Not Serializable in a Spark Data-frame)
   * @return
   */
  def serializeMap(map: Map[String, Any]): Option[String] = {
    if (map != null && map.nonEmpty) Option(toJson(map)) else None
  }

  /**
   * Converts any object to respective JSON String
   *
   * @param value
   * @return
   */
  def toJson(value: Any): String = {
    mapper.writeValueAsString(value)
  }

  /**
   * Converts Any value to Array of Bytes
   *
   * @param value
   * @return
   */
  def toByteArray(value: Any): Array[Byte] = mapper.writeValueAsBytes(value)

  /**
   * Converts Array of Bytes to respective data-type
   *
   * @param value
   * @param m
   * @param T
   * @return
   */
  def fromByteArray[T](value: Array[Byte])(implicit m: Manifest[T]): T = {
    mapper.readValue[T](value)
  }

  @throws(classOf[JsonProcessingException])
  def mergeJSONMaps(
      baseInput: Map[String, Any],
      inputToMerge: Map[String, Any]
  ): String = {
    val json1 = toJson(baseInput)
    val json2 = toJson(inputToMerge)
    val mainNode = mapper.readTree(json1)
    val updateNode = mapper.readTree(json2)

    val mergedNode = merge(mainNode, updateNode)

    toJson(mergedNode)
  }

  /**
   * Converts the JSON String to Map[String,V(Type)]
   *
   * @param json
   * @param m
   * @tparam V
   * @return
   */
  def toMap[V](json: String)(implicit m: Manifest[V]): Map[String, V] =
    fromJson[Map[String, V]](json)

  /**
   * Converts the JSON String to Object of T type
   *
   * @param json
   * @param m
   * @tparam T
   * @return
   */
  def fromJson[T](json: String)(implicit m: Manifest[T]): T = {
    mapper.readValue[T](json)
  }

  private def merge(mainNode: JsonNode, updateNode: JsonNode): JsonNode = {
    val fieldNames = updateNode.fieldNames
    while (fieldNames.hasNext) {
      val updatedFieldName = fieldNames.next
      val valueToBeUpdated = mainNode.get(updatedFieldName)
      val updatedValue = updateNode.get(updatedFieldName)
      // If the node is an @ArrayNode
      if (valueToBeUpdated != null && valueToBeUpdated.isArray && updatedValue.isArray) { // running a loop for all elements of the updated ArrayNode
        for (i <- 0 until updatedValue.size()) {
          val updatedChildNode = updatedValue.get(i)
          // Create a new Node in the node that should be updated, if there was no corresponding node in it
          // Use-case - where the updateNode will have a new element in its Array
          if (valueToBeUpdated.size <= i)
            valueToBeUpdated.asInstanceOf[ArrayNode].add(updatedChildNode)
          // getting reference for the node to be updated
          val childNodeToBeUpdated = valueToBeUpdated.get(i)
          merge(childNodeToBeUpdated, updatedChildNode)
        } // if the Node is an @ObjectNode
      } else if (valueToBeUpdated != null && valueToBeUpdated.isObject)
        merge(valueToBeUpdated, updatedValue)
      else if (mainNode.isInstanceOf[ObjectNode])
        mainNode.asInstanceOf[ObjectNode].replace(updatedFieldName, updatedValue)
    }
    mainNode
  }

}
