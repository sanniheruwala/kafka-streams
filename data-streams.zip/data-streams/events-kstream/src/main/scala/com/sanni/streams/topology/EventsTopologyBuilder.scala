package com.sanni.streams.topology

import com.sanni.streams.models.OutputEvent
import com.sanni.streams.config.KafkaConfig
import com.sanni.streams.helpers.JsonUtil
import com.sanni.streams.models.{Event, OutputEvent}
import com.sanni.streams.serde.JSONSerde
import org.apache.kafka.streams.scala.ImplicitConversions._
import org.apache.kafka.streams.scala.Serdes._
import org.apache.kafka.streams.scala.StreamsBuilder
import org.apache.kafka.streams.scala.kstream.{KStream, KTable}

class EventsTopologyBuilder()(implicit config: KafkaConfig) extends BaseTopology {
  // Add implicit Serde
  implicit val eventSerde: JSONSerde[Event] = new JSONSerde[Event]
  implicit val outputEventSerde: JSONSerde[OutputEvent] = new JSONSerde[OutputEvent]

  override def init(): StreamsBuilder = {

    val builder: StreamsBuilder = new StreamsBuilder
    val inputStream: KStream[String, Event] =
      builder.stream[String, Event](config.topic.input)

    val metaTable: KTable[String, Event] =
      builder.table[String, Event](config.topic.metadata)

    val enrichedStream: KStream[String, OutputEvent] = inputStream
      .leftJoin(metaTable)(joiner)

    enrichedStream.to(config.topic.output)

    builder
  }

  private def joiner: (Event, Event) => OutputEvent =
    (event1: Event, event2: Event) => {
      val mergedProperties = JsonUtil.mergeJSONMaps(event1.properties, event2.properties)
      val mergedEvent = OutputEvent(
        event1.eventName,
        event1.eventType,
        event1.version,
        Some(event1.source),
        Some(event1.eventTimestampRaw.toString),
        Some(event1.eventTimestamp),
        Some(event1.producerTimestamp),
        event1.serializableContext,
        Some(mergedProperties),
        event1.createdDate,
        event1.producerCreatedDate,
        event1.consumerTimestamp,
        event1.uuid,
        event1.requestId,
        event1.mode,
        "",
        event1.read_key,
        event1.write_key,
        event1.serializedMetaData
      )
      mergedEvent
    }

}
