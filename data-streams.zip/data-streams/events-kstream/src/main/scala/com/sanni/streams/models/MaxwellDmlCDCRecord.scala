package com.sanni.streams.models

import org.json4s.JObject

case class MaxwellDmlRecord (
  database: String,
  table: String,
  `type`: String,
  ts: Long,
  xid: Long,
  commit: Boolean,
  position: String,
  primary_key_columns: Option[Array[String]],
  data: Map[String, Any],
  old: Option[Map[String, Any]]
)
