package com.sanni.streams

import java.time.Duration
import com.sanni.streams.config._
import com.sanni.streams.bootstrap.Bootstrap
import com.sanni.streams.config.KafkaConfig
import com.sanni.streams.constants.App
import com.sanni.streams.helpers.Configuration
import com.sanni.streams.listeners.LoggingStateListener
import com.sanni.streams.topology.BaseTopology
import org.apache.kafka.streams.KafkaStreams
import org.apache.kafka.streams.scala.StreamsBuilder
import org.apache.logging.log4j.LogManager

trait StreamApp extends App with Bootstrap {

  protected val logger = LogManager.getLogger(this.getClass)

  logger.info("Config for KStreams app")

  lazy implicit val kafkaConfig: KafkaConfig = appConfig.kafkaConfig
  val builder: StreamsBuilder = initTopology().init()

  val app: KafkaStreams =
    new KafkaStreams(builder.build(), kafkaConfig.getTopologyProperties())

  app.setStateListener(new LoggingStateListener(app))
  app.setUncaughtExceptionHandler((thread: Thread, exception: Throwable) => {
    logger.error(
      s"Thread=[${thread.getName}] encountered=[${exception.getLocalizedMessage}]. Will exit."
    )
    System.exit(1)
  })

  try app.start()
  catch {
    case e: Exception =>
      logger.error(s"Error starting - ${e.getLocalizedMessage}")
      System.exit(1)
  }

  logger.info(s"KStream app status: ${app.state.isRunningOrRebalancing}")

  sys.ShutdownHookThread {
    logger.info("Shutting down KStream app")
    if (app != null) app.close(Duration.ofSeconds(30))
  }

  def initTopology(): BaseTopology
}
