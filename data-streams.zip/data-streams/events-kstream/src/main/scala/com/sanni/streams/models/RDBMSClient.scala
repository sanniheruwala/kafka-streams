package com.sanni.streams.models

import com.sanni.streams.config.DBConfig
import scalikejdbc.NamedDB
import scalikejdbc._

import scala.collection.mutable

case class Connection(
    name: String,
    driverClass: String,
    driver: String
) {
  def conn: NamedDB = NamedDB(name)
}

object RDBMSClient {
  var connections: mutable.Map[String, Connection] = mutable.Map()

  def resolveConnection(
      database: String
  )(implicit dbConfig: DBConfig): Connection = {
    val connectionName = s"${database}"
    val savedConnection = connections.get(connectionName)

    if (savedConnection.isEmpty) {

      Class.forName(dbConfig.driverClass)
      val settings: ConnectionPoolSettings = ConnectionPoolSettings(
        initialSize = dbConfig.connectionPool.poolInitialSize,
        maxSize = dbConfig.connectionPool.poolMaxSize,
        connectionTimeoutMillis = dbConfig.connectionPool.connectionTimeoutMs,
        validationQuery = dbConfig.connectionPool.validationQuery
      )

      val urlAdditionalArgs = dbConfig.driver match {
        // Let postgres server infer string types whether its a json, varchar or char
        // default value for this property is `string` i.e. treat all strings types as varchar
        case "postgresql" => "?stringtype=unspecified"
        case "mysql"    => ""
//          "?sessionVariables=tidb_dml_batch_size=20000" +
//          "&sessionVariables=tidb_batch_insert=1&sessionVariables=tidb_batch_delete=1"
      }

      val url = dbConfig.url + "/" + database + urlAdditionalArgs

      ConnectionPool.add(
        connectionName,
        url,
        dbConfig.user,
        dbConfig.password,
        settings
      )

      connections(connectionName) = Connection(
        connectionName,
        dbConfig.driverClass,
        dbConfig.driver
      )
    }

    connections(connectionName)
  }
}
