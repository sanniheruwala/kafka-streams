package com.sanni.streams.topology

import org.apache.kafka.streams.scala.StreamsBuilder
import org.apache.logging.log4j.LogManager

abstract class BaseTopology {
  protected val logger = LogManager.getLogger(this.getClass)
  def init(): StreamsBuilder
}
