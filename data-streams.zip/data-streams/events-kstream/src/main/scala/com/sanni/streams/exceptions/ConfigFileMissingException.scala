package com.sanni.streams.exceptions

case class ConfigFileMissingException(message: String,
                                      cause: Throwable = None.orNull)
    extends Exception(message, cause)
