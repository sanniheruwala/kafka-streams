package com.sanni.streams.helpers

import java.time.format.DateTimeFormatter
import java.time.{Instant, LocalDate, ZoneId, ZonedDateTime}

object DateUtil {
  val IST_TIMEZONE: String = "Asia/Calcutta"
  val IST_ZONE_ID: ZoneId = ZoneId.of(IST_TIMEZONE)

  val UTC_TIMEZONE: String = "UTC"
  val UTC_ZONE_ID: ZoneId = ZoneId.of(UTC_TIMEZONE)

  val ZONE_ID_MAP: Map[String, ZoneId] =
    Map("ist" -> IST_ZONE_ID, "utc" -> UTC_ZONE_ID)

  def getCurrentDate(): String = {
    val today = LocalDate.now(IST_ZONE_ID)
    today.toString
  }

  def getCurrentTs(): Long = {
    Instant.now().toEpochMilli
  }

  def getDateFromTsMilli(ts: Long, tz: String = "ist"): String = {
    formatTsMilli(ts, "yyyy-MM-dd", tz)
  }

  def formatTsMilli(ts: Long,
                    format: String = "yyyy-MM-dd'T'HH:mm:ss.A",
                    tz: String = "ist"): String = {
    val instant = Instant.ofEpochMilli(ts)
    val timeAtZone = ZonedDateTime.ofInstant(instant, ZONE_ID_MAP(tz))
    val formattedDateTime =
      timeAtZone.format(DateTimeFormatter.ofPattern(format))

    formattedDateTime
  }

  def getDateFromTsSecond(ts: Long, tz: String = "ist"): String = {
    formatTsSecond(ts, "yyyy-MM-dd", tz)
  }

  def formatTsSecond(ts: Long,
                     format: String = "yyyy-MM-dd'T'HH:mm:ss.A",
                     tz: String = "ist"): String = {
    val instant = Instant.ofEpochSecond(ts)
    val timeAtZone = ZonedDateTime.ofInstant(instant, ZONE_ID_MAP(tz))
    val formattedDateTime =
      timeAtZone.format(DateTimeFormatter.ofPattern(format))

    formattedDateTime
  }

  def formatDateStringToTs(dateStr: String): Long = {
    ZonedDateTime.parse(dateStr).toInstant.toEpochMilli
  }
}
