package com.sanni.streams.config

case class KafkaSSLConfig(
    enable: Boolean,
    securityProtocol: Option[String],
    truststoreLocation: Option[String],
    truststorePassword: Option[String],
    keystoreLocation: Option[String],
    keystorePassword: Option[String]
)
