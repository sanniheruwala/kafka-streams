package com.sanni.streams.serde

import com.sanni.streams.helpers.JsonUtil

import java.util
import org.apache.kafka.common.serialization.{Deserializer, Serde, Serializer}

/**
  * JSON serializer for JSON serde
  *
  * @tparam T
  */
class JSONSerializer[T] extends Serializer[T] {
  override def configure(configs: util.Map[String, _], isKey: Boolean): Unit =
    ()

  override def serialize(topic: String, data: T): Array[Byte] =
    JsonUtil.toByteArray(data)

  override def close(): Unit = ()
}

/**
  * JSON deserializer for JSON serde
  *
  * @tparam T
  */
class JSONDeserializer[T >: Null <: Any: Manifest] extends Deserializer[T] {
  override def configure(configs: util.Map[String, _], isKey: Boolean): Unit =
    ()

  override def close(): Unit = ()

  override def deserialize(topic: String, data: Array[Byte]): T = {
    if (data == null) {
      return null
    } else {
      JsonUtil.fromByteArray[T](data)
    }
  }
}

/**
  * JSON serde for local state serialization
  *
  * @tparam T
  */
class JSONSerde[T >: Null <: Any: Manifest] extends Serde[T] {
  override def deserializer(): Deserializer[T] = new JSONDeserializer[T]

  override def configure(configs: util.Map[String, _], isKey: Boolean): Unit =
    ()

  override def close(): Unit = ()

  override def serializer(): Serializer[T] = new JSONSerializer[T]
}
