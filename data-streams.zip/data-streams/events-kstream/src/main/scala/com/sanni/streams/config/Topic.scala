package com.sanni.streams.config

case class Topic(input: String, metadata: String, output: String)
