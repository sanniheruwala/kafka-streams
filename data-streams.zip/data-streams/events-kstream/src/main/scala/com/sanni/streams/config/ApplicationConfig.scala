package com.sanni.streams.config

class BaseApplicationConfig(
  kafka: KafkaConfig
) {
  val kafkaConfig: KafkaConfig = kafka
}

sealed case class ApplicationConfig(
  kafka: KafkaConfig
) extends BaseApplicationConfig(kafka)

sealed case class PaymentsCardApplicationConfig(
  kafka: KafkaConfig,
  dbConfig: DBConfig
) extends BaseApplicationConfig(kafka)
