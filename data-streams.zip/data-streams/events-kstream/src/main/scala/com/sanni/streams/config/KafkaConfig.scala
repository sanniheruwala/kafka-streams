package com.sanni.streams.config

import java.util.Properties

import org.apache.kafka.common.config.SslConfigs
import org.apache.kafka.streams.StreamsConfig

case class KafkaConfig(
    applicationId: String,
    bootstrapServers: String,
    serde: SerdeConfig,
    topic: Topic,
    ssl: KafkaSSLConfig
) {

  def getTopologyProperties(): Properties = {
    val properties = new Properties()
    properties.put(StreamsConfig.APPLICATION_ID_CONFIG, applicationId)
    properties.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers)
    // Add SSL config
    if (ssl.enable) {
      properties.put(StreamsConfig.SECURITY_PROTOCOL_CONFIG, ssl.securityProtocol.get)
      properties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, ssl.truststoreLocation.get)
      properties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, ssl.truststorePassword.get)
      properties.put(
        SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,
        ssl.keystoreLocation.get
      )
      properties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, ssl.keystorePassword.get)
      properties.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "")
    }
    properties
  }

}
