package com.sanni.streams

import com.sanni.streams.config.PaymentsCardApplicationConfig
import com.sanni.streams.topology.BaseTopology
import com.sanni.streams.config.{DBConfig, PaymentsCardApplicationConfig}
import com.sanni.streams.constants.App
import com.sanni.streams.helpers.Configuration
import com.sanni.streams.topology.{BaseTopology, PaymentsTransformationBuilder}

object PaymentsCardStreamApp extends StreamApp {

  import pureconfig.generic.auto._

  override def appConfig: PaymentsCardApplicationConfig = Configuration.app[PaymentsCardApplicationConfig](
    env, App.PAYMENTS_STREAM_JOB_CONF_FILE
  )

  lazy implicit val dbConfig: DBConfig = appConfig.dbConfig

  override def initTopology(): BaseTopology = {
    new PaymentsTransformationBuilder()
  }

}
