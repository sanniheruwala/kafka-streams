package com.sanni.streams.models

import java.time._
import com.fasterxml.jackson.annotation.JsonProperty
import com.sanni.streams.helpers.JsonUtil.serializeMap
import com.sanni.streams.helpers.DateUtil

import scala.util.Try

/**
 * Json Event SerDe
 * Context and Properties are non serializable, have to be converted to Map[String, String]
 *
 * @param eventName
 * @param eventType
 * @param source
 * @param eventTimestampRaw
 * @param producerTimestamp Producer Timestamp(ms)
 * @param context
 * @param properties
 */
case class Event(
    @JsonProperty("event_name")
    eventName: String,
    @JsonProperty("event_type")
    eventType: String,
    @JsonProperty("version")
    version: Option[String],
    @JsonProperty("source")
    source: String,
    @JsonProperty("event_timestamp")
    eventTimestampRaw: Any,
    @JsonProperty("producer_timestamp")
    producerTimestamp: Long,
    @JsonProperty("context")
    context: Map[String, Any],
    @JsonProperty("properties")
    properties: Map[String, Any],
    @JsonProperty("uuid")
    uuid: Option[String],
    @JsonProperty("request_id")
    requestId: Option[String],
    @JsonProperty("mode")
    mode: String,
    @JsonProperty("read_key")
    read_key: Option[Array[String]],
    @JsonProperty("write_key")
    write_key: Option[String],
    @JsonProperty("metadata")
    metadata: Option[Map[String, Any]]
) extends Serializable {

  // ----- Time and partition related -----
  private val now: ZonedDateTime = ZonedDateTime.now(ZoneId.of("UTC"))

  val consumerTimestamp: Long = now.toEpochSecond

  val producerCreatedDate: String =
    DateUtil.getDateFromTsSecond(producerTimestamp)

  var eventTimestamp: Long = 0

  eventTimestampRaw match {
    case v: String => {
      if (Try(v.toLong).isSuccess) {
        eventTimestamp = v.toLong
      } else {
        eventTimestamp = DateUtil.formatDateStringToTs(v)
      }
    }
    case v: Long => eventTimestamp = v
    case v: Int  => eventTimestamp = v
  }

  // Convert millisecond / microsecond eventTimestamp to seconds
  // by truncating the value to 1st 10 digits
  // Here we assume that any number having more than 10 digits corresponds to 230/milliseconds
  eventTimestamp = eventTimestamp.toString.slice(0, 10).toInt

  // Adding a few timestamps and formatted timestamps that'll be later used for partitioning
  var createdDate: String = DateUtil.getDateFromTsSecond(eventTimestamp)

  val serializableProperties: Option[String] = serializeMap(properties)
  // ----- Serializing JSON/MAP/Array fields -----
  // Some of the fields (that contain actual event data) are arbitrary fluid MAPs
  // that we must serialize for Parquet storage. Later in Presto (DB layer) we
  // can define these fields with various data types like MAP, Array, JSON, etc.
  val serializableContext: Option[String] = serializeMap(context)
  val meta = if (metadata.isDefined) metadata.get else null;
  val serializedMetaData: Option[String] = serializeMap(meta)

}

case class OutputEvent(
    event_name: String,
    event_type: String,
    version: Option[String] = None,
    source: Option[String] = None,
    event_timestamp_raw: Option[String] = None,
    event_timestamp: Option[Long] = None,
    producer_timestamp: Option[Long] = None,
    context: Option[String] = None,
    properties: Option[String] = None,
    created_date: String,
    producer_created_date: String,
    consumer_timestamp: Long,
    uuid: Option[String] = None,
    request_id: Option[String] = None,
    mode: String,
    subject: String,
    read_key: Option[Array[String]],
    write_key: Option[String],
    metadata: Option[String]
) extends Serializable
