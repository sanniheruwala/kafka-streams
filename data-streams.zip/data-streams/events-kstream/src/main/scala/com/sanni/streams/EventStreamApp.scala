package com.sanni.streams

import com.sanni.streams.topology.{BaseTopology, EventsTopologyBuilder}
import com.sanni.streams.config.ApplicationConfig
import com.sanni.streams.constants.App
import com.sanni.streams.helpers.Configuration
import com.sanni.streams.topology.{BaseTopology, EventsTopologyBuilder}

object EventStreamApp extends StreamApp {

  import pureconfig.generic.auto._
  override def appConfig: ApplicationConfig  = Configuration.app[ApplicationConfig](
    env, App.EVENTS_STREAM_JOB_CONF_FILE
  )
  override def initTopology(): BaseTopology = {
    new EventsTopologyBuilder()
  }

}
