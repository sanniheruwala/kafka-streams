package com.sanni.streams.config

import com.sanni.streams.constants.App

case class DBConfig(
  enabled: Boolean,
  host: String,
  port: Int,
  driver: String,
  user: String,
  password: String,
  connectionPool: ConnectionPoolSettings
) {
  val driverClass: String = driver match {
    case "postgresql" => App.POSTGRES_JDBC_DRIVER_CLASS
    case "mysql" => App.MYSQL_JDBC_DRIVER_CLASS
    case _ => throw new Exception(s"Driver $driver not supported")
  }

  val url: String = s"jdbc:$driver://$host:$port"
}

case class ConnectionPoolSettings(
  poolInitialSize: Int,
  poolMaxSize: Int,
  connectionTimeoutMs: Int,
  validationQuery: String = "SELECT 1"
)
