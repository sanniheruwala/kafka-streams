package com.sanni.streams.models

case class inputData(
                  database: String,
                  table: String,
                  `type`: String,
                  ts: Long,
                  xid: Option[Long],
                  xoffset: Option[Long],
                  position: String,
                  primary_key_columns: Option[Array[String]],
                  data: Map[String, Any],
                  old: Option[Map[String, Any]])

case class outputData(data: Map[String, Any])