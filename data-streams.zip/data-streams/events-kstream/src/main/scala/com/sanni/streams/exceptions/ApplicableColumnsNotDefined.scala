package com.sanni.streams.exceptions

case class ApplicableColumnsNotDefined(
  message: String,
  cause: Throwable = None.orNull)
extends Exception(message, cause)
