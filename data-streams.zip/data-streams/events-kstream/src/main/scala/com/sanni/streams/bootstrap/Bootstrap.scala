package com.sanni.streams.bootstrap

import com.sanni.streams.config._
import com.sanni.streams.config.BaseApplicationConfig
import com.sanni.streams.helpers.Utils

trait Bootstrap {
  val env = Utils.getEnv
  def appConfig: BaseApplicationConfig
}
