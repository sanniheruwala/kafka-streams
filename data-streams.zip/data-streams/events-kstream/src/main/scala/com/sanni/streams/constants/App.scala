package com.sanni.streams.constants

object App {
  final val ENV_VARIABLE = "APP_ENV"

  final val PRODUCTION_ENV = "prod"
  final val STAGE_ENV = "stage"
  final val DEV_ENV = "dev"
  final val PERF_ENV = "perf"
  final val TEST_ENV = "test"
  final val DEFAULT_ENV = DEV_ENV
  // Config files
  val DEFAULT_APP_CONFIG_FILE_NAME = "application.conf"
  val EVENTS_STREAM_JOB_CONF_FILE = "events_stream_app.conf"
  val PAYMENTS_CARD_STREAM_JOB_CONF_FILE = "payments_card_stream_app.conf"
  val PAYMENTS_STREAM_JOB_CONF_FILE = "payments_stream_app.conf"


  final val RESOURCES_PATH = "src/main/resources"

  val MYSQL_JDBC_DRIVER_CLASS = "com.mysql.cj.jdbc.Driver"
  val POSTGRES_JDBC_DRIVER_CLASS = "org.postgresql.Driver"
}
