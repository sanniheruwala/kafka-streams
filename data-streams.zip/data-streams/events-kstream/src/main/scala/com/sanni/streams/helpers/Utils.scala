package com.sanni.streams.helpers

import com.sanni.streams.constants.App

object Utils {
  def getEnv(): String =
//    sys.env.getOrElse(App.ENV_VARIABLE, App.DEFAULT_ENV).toLowerCase()
  return "perf"
}
