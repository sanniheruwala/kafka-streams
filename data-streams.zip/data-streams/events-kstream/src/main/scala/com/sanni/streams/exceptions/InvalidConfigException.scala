package com.sanni.streams.exceptions

case class InvalidConfigException(message: String,
                                  cause: Throwable = None.orNull)
    extends Exception(message, cause)
