package com.sanni.streams.models

import org.json4s.JObject

case class DebeziumSource(
  version: String,
  connector: String,
  name: String,
  ts_ms: Long,
  snapshot: String,
  db: String,
  schema: String,
  table: String,
  txId: Long,
  lsn: Long,
  xmin: Option[String]
)


case class DebeziumPostgresRecord(
  before: Option[Map[String, Any]],
  after: Option[Map[String, Any]],
  op: String,
  ts_ms: Long,
  source: DebeziumSource,
  transaction: Option[String],
  _record_source: String
)
