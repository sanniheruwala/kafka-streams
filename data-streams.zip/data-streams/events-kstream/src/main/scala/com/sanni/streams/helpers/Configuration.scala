package com.sanni.streams.helpers

import com.sanni.streams.exceptions.InvalidConfigException
import com.typesafe.config.ConfigFactory
import com.sanni.streams.config.{ApplicationConfig, BaseApplicationConfig}
import com.sanni.streams.exceptions.{ConfigFileMissingException, InvalidConfigException}
import pureconfig.error.ConfigReaderFailures
import pureconfig.ConfigReader

object Configuration {

  import pureconfig.generic.auto._
  def app[T <: BaseApplicationConfig: ConfigReader](environment: String, filename: String): T = {

    val config:Either[ConfigReaderFailures, T] = pureconfig.loadConfig[T](load(environment, filename))

    config match {
      case Right(value) => value
      case Left(value)  => throw InvalidConfigException(value.head.description)
    }

  }

  def load(env: String, fileName: String) = {

    val path = s"$env/$fileName"
    val config =
      Thread.currentThread().getContextClassLoader.getResourceAsStream(path)
    if (config == null)
      throw ConfigFileMissingException(s"file not found in ${path}")
    ConfigFactory.parseString(scala.io.Source.fromInputStream(config).mkString).resolve()

  }

}
