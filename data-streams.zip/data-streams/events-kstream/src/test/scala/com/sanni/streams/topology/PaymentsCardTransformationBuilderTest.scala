package com.sanni.streams.topology

import com.sanni.streams.exceptions.InvalidOpTypeException
import com.sanni.streams.UnitTests
import com.sanni.streams.config.PaymentsCardApplicationConfig
import com.sanni.streams.constants.App
import com.sanni.streams.exceptions.{ApplicableColumnsNotDefined, InvalidOpTypeException}
import com.sanni.streams.helpers.Configuration
import org.postgresql.util.{PGobject, PSQLException}

class PaymentsCardTransformationBuilderTest extends UnitTests {
  import pureconfig.generic.auto._

  val appConfig = Configuration.app[PaymentsCardApplicationConfig](
    "test",
    App.PAYMENTS_CARD_STREAM_JOB_CONF_FILE
  )

  implicit def kafkaConfig = appConfig.kafka
  implicit def dbConfig = appConfig.dbConfig

  val paymentsCardTopology: PaymentsCardTransformationBuilder =
    new PaymentsCardTransformationBuilder()

  "Transactions Field" should "return recurring as 1 when type is recurring and stripped recurring value in recurring type" in {
    val transactionData: String = """{"type": "recurring_auto"}"""
    val transactionsColumns = paymentsCardTopology.extractFromTransactionTypeField(transactionData)
    transactionsColumns should contain("recurring" -> 1)
    transactionsColumns should contain("recurring_type" -> "auto")
  }

  it should "return recurring as 0 and recurring type as None/null when type is not recurring" in {
    val transactionData: String = """{"type": "emandate"}"""
    val transactionsColumns = paymentsCardTopology.extractFromTransactionTypeField(transactionData)
    transactionsColumns should contain("recurring" -> 0)
    transactionsColumns.keys.toList should contain("recurring_type")
    transactionsColumns("recurring_type") should be(None)
  }

  it should "return recurring as 0 and recurring type as None/null when type is None in input parameter" in {
    val transactionData: Option[String] = None
    val transactionsColumns = paymentsCardTopology.extractFromTransactionTypeField(transactionData)
    transactionsColumns should contain("recurring" -> 0)
    transactionsColumns.keys.toList should contain("recurring_type")
    transactionsColumns("recurring_type") should be(None)
  }

  it should "return recurring as 0 and recurring type as None/null when type is null in the source" in {
    val transactionData: Option[String] = null
    val transactionsColumns = paymentsCardTopology.extractFromTransactionTypeField(transactionData)
    transactionsColumns should contain("recurring" -> 0)
    transactionsColumns.keys.toList should contain("recurring_type")
    transactionsColumns("recurring_type") should be(None)
  }

  it should "return recurring as 0 and recurring type as None/null when data is queried from postgres" in {
    val transactionData = new PGobject()
    transactionData.setValue("""{"type": "recurring_auto"}""")
    val transactionsColumns = paymentsCardTopology.extractFromTransactionTypeField(transactionData)
    transactionsColumns should contain("recurring" -> 1)
    transactionsColumns should contain("recurring_type" -> "auto")
  }

  "Gateway Reference Field" should "return Map with reference2 as a key" in {
    val gatewayReferenceData: String = """{"auth_code": "1234"}"""
    val gatewayReferenceColumns =
      paymentsCardTopology.extractFromGatewayReferenceField(gatewayReferenceData)
    gatewayReferenceColumns should contain("reference2" -> "1234")
  }

  it should "return reference2 as None/null when type is None in input parameter" in {
    val gatewayReferenceData: Option[String] = None
    val gatewayReferenceColumns =
      paymentsCardTopology.extractFromGatewayReferenceField(gatewayReferenceData)
    gatewayReferenceColumns.keys.toList should contain("reference2")
    gatewayReferenceColumns("reference2") should be(None)
  }

  it should "return reference2 as None/null when type is null in input parameter" in {
    val gatewayReferenceData: Option[String] = null
    val gatewayReferenceColumns =
      paymentsCardTopology.extractFromGatewayReferenceField(gatewayReferenceData)
    gatewayReferenceColumns.keys.toList should contain("reference2")
    gatewayReferenceColumns("reference2") should be(None)
  }

  it should "return recurring as 0 and recurring type as None/null when data is queried from postgres" in {
    val gatewayReferenceData = new PGobject()
    gatewayReferenceData.setValue("""{"auth_code": "1234"}""")
    val gatewayReferenceColumns =
      paymentsCardTopology.extractFromGatewayReferenceField(gatewayReferenceData)
    gatewayReferenceColumns should contain("reference2" -> "1234")
  }

  "Terminals Field" should "return Map with terminal Id and gateway as a key" in {
    def processTestWithValue(columnData: Any): Unit = {
      val terminalsColumns = paymentsCardTopology.extractFromTerminalField(columnData)
      terminalsColumns should contain("terminal_id" -> "DiH73Dhrl8")
      terminalsColumns should contain("gateway" -> "hitachi")
    }
    processTestWithValue("""{ "terminal_id": "DiH73Dhrl8", "gateway": "hitachi" }""")
    val pgObj = new PGobject()
    pgObj.setValue("""{ "terminal_id": "DiH73Dhrl8", "gateway": "hitachi" }""")
    processTestWithValue(pgObj)
  }

  it should "return reference2 as None/null when type is None/null in input parameter" in {
    def processTestWithValue(columnData: Any): Unit = {
      val terminalsColumns = paymentsCardTopology.extractFromTerminalField(columnData)
      terminalsColumns.keys.toList should contain("terminal_id")
      terminalsColumns("terminal_id") should be(None)
      terminalsColumns("gateway") should be(None)
    }
    processTestWithValue(None)
    processTestWithValue(null)
  }

  it should "return Map if only one of the keys is set in incoming event" in {
    val columnData = """{ "terminal_id": "DiH73Dhrl8"}"""
    val terminalsColumns = paymentsCardTopology.extractFromTerminalField(columnData)
    terminalsColumns should contain("terminal_id" -> "DiH73Dhrl8")
    terminalsColumns("gateway") should be(None)
  }

  "Error Field" should "return Map with 4 error columns keys" in {
    def processTestWithValue(columnData: Any): Unit = {
      val errorColumns = paymentsCardTopology.extractFromErrorField(columnData)
      errorColumns.keys.toList.length should be(4)
      errorColumns should contain("error_code" -> "INTERNAL_SERVER_ERROR")
      errorColumns should contain("internal_error_code" -> 500)
      errorColumns should contain("error_description" -> "Invalid certificate")
      errorColumns should contain("cancellation_reason" -> null)
    }
    val colmValue =
      """{ "error_code": "INTERNAL_SERVER_ERROR", "internal_error_code": 500, "error_description": "Invalid certificate", "cancellation_reason": null }"""
    processTestWithValue(colmValue)
    val pgObj = new PGobject()
    pgObj.setValue(colmValue)
    processTestWithValue(pgObj)
  }

  it should "return error columns as None/null when type is None/null in input parameter" in {
    def processTestWithValue(columnData: Any): Unit = {
      val errorColumns = paymentsCardTopology.extractFromErrorField(columnData)
      errorColumns.keys.toList.length should be(4)
      errorColumns.keys.toList should contain allOf (
        "error_code", "internal_error_code", "error_description", "cancellation_reason"
      )
      errorColumns("error_code") should be(None)
      errorColumns("internal_error_code") should be(None)
    }
    processTestWithValue(None)
    processTestWithValue(null)
  }

  it should "return Map with all error columns even if if only one of the keys is set in incoming event" in {
    val columnData = """{ "error_code": "INTERNAL_SERVER_ERROR", "internal_error_code": 500}"""
    val errorColumns = paymentsCardTopology.extractFromErrorField(columnData)
    errorColumns.keys.toList should contain allOf (
      "error_code", "internal_error_code", "error_description", "cancellation_reason"
    )
    errorColumns should contain("error_code" -> "INTERNAL_SERVER_ERROR")
    errorColumns should contain("internal_error_code" -> 500)
    errorColumns should contain("error_description" -> None)
  }

  "Emi Field" should "return Map with 2 emi columns keys" in {
    def processTestWithValue(columnData: Any): Unit = {
      val emiColumns = paymentsCardTopology.extractFromEmiField(columnData)
      emiColumns.keys.toList.length should be(2)
      emiColumns should contain("emi_plan_id" -> "1234")
      emiColumns should contain("emi_subvention" -> 1)
    }
    val colmValue = """{ "emi_plan_id": "1234", "subvention": 1}"""
    processTestWithValue(colmValue)
    val pgObj = new PGobject()
    pgObj.setValue(colmValue)
    processTestWithValue(pgObj)
  }

  it should "return emi columns as None/null when type is None/null in input parameter" in {
    def processTestWithValue(columnData: Any): Unit = {
      val emiColumns = paymentsCardTopology.extractFromEmiField(columnData)
      emiColumns.keys.toList.length should be(2)
      emiColumns.keys.toList should contain allOf (
        "emi_plan_id", "emi_subvention"
      )
      emiColumns("emi_plan_id") should be(None)
      emiColumns("emi_subvention") should be(None)
    }
    processTestWithValue(None)
    processTestWithValue(null)
  }

  it should "return Map with all emi columns even if only one of the keys is set in incoming event" in {
    val columnData = """{ "emi_plan_id": "1234"}"""
    val emiColumns = paymentsCardTopology.extractFromEmiField(columnData)
    emiColumns should contain("emi_plan_id" -> "1234")
    emiColumns.keys.toList.length should be(2)
    emiColumns.keys.toList should contain allOf (
      "emi_plan_id", "emi_subvention"
    )
    emiColumns should contain("emi_subvention" -> None)
  }

  "Product Field" should "return Map with 4 product columns keys" in {
    def processTestWithValue(columnData: Any): Unit = {
      val productColumns = paymentsCardTopology.extractFromProductField(columnData)
      productColumns.keys.toList.length should be(4)
      productColumns should contain("invoice_id" -> "1234")
      productColumns should contain("subscription_id" -> None)
      productColumns should contain("transfer_id" -> None)
      productColumns should contain("payment_link_id" -> None)
    }
    val colmValue = """{ "product_type": "invoice", "product_id": "1234"}"""
    processTestWithValue(colmValue)
    val pgObj = new PGobject()
    pgObj.setValue(colmValue)
    processTestWithValue(pgObj)
  }

  it should "return product columns as None/null when type is None/null in input parameter" in {
    def processTestWithValue(columnData: Any): Unit = {
      val productColumns = paymentsCardTopology.extractFromProductField(columnData)
      productColumns.keys.toList.length should be(4)
      productColumns.keys.toList should contain allOf (
        "invoice_id", "subscription_id", "transfer_id", "payment_link_id"
      )
      productColumns("invoice_id") should be(None)
      productColumns("subscription_id") should be(None)
      productColumns("transfer_id") should be(None)
      productColumns("payment_link_id") should be(None)
    }
    processTestWithValue(None)
    processTestWithValue(null)
  }

  it should "return Map with all product ids columns even if product doesn't match any specified product" in {
    val columnData = """{ "product_type": "new_product", "product_id": "1234"}"""
    val productColumns = paymentsCardTopology.extractFromProductField(columnData)
    productColumns.keys.toList.length should be(4)
    productColumns.keys.toList should contain allOf (
      "invoice_id", "subscription_id", "transfer_id", "payment_link_id"
    )
    productColumns("invoice_id") should be(None)
    productColumns("subscription_id") should be(None)
    productColumns("transfer_id") should be(None)
    productColumns("payment_link_id") should be(None)
  }

  it should "return Map with all product ids columns with None value if product id is not specified" in {
    val columnData = """{ "product_type": "new_product" }"""
    val productColumns = paymentsCardTopology.extractFromProductField(columnData)
    productColumns.keys.toList.length should be(4)
    productColumns.keys.toList should contain allOf (
      "invoice_id", "subscription_id", "transfer_id", "payment_link_id"
    )
    productColumns("invoice_id") should be(None)
    productColumns("subscription_id") should be(None)
    productColumns("transfer_id") should be(None)
    productColumns("payment_link_id") should be(None)
  }

  "Card Field" should "return Map with 2 card columns keys" in {
    def processTestWithValue(columnData: Any): Unit = {
      val cardColumns = paymentsCardTopology.extractFromCardsField(columnData)
      cardColumns.keys.toList.length should be(2)
      cardColumns should contain("card_id" -> "1234")
      cardColumns should contain("save" -> 1)
    }
    val colmValue = """{ "card_id": "1234", "save": 1}"""
    processTestWithValue(colmValue)
    val pgObj = new PGobject()
    pgObj.setValue(colmValue)
    processTestWithValue(pgObj)
  }

  it should "return card columns as None/null when type is None/null in input parameter" in {
    def processTestWithValue(columnData: Any): Unit = {
      val cardColumns = paymentsCardTopology.extractFromCardsField(columnData)
      cardColumns.keys.toList.length should be(2)
      cardColumns.keys.toList should contain allOf (
        "card_id", "save"
      )
      cardColumns("card_id") should be(None)
      cardColumns("save") should be(0)
    }
    processTestWithValue(None)
    processTestWithValue(null)
  }

  it should "return Map with all card columns even if only one of the keys is set in incoming event" in {
    val columnData = """{ "save": 1 }"""
    val cardColumns = paymentsCardTopology.extractFromCardsField(columnData)
    cardColumns should contain("save" -> 1)
    cardColumns.keys.toList.length should be(2)
    cardColumns.keys.toList should contain allOf (
      "card_id", "save"
    )
    cardColumns should contain("card_id" -> None)
  }

  it should "return Map with all save column value as 0 when event doesn't have the value set" in {
    val columnData = """{ "card_id": "1234" }"""
    val cardColumns = paymentsCardTopology.extractFromCardsField(columnData)
    cardColumns should contain("save" -> 0)
    cardColumns.keys.toList.length should be(2)
  }

  it should "return Map with all save column value as 0 when save is set as null" in {
    val columnData = """{ "card_id": "1234", "save": null }"""
    val cardColumns = paymentsCardTopology.extractFromCardsField(columnData)
    cardColumns should contain("save" -> 0)
    cardColumns.keys.toList.length should be(2)
  }

  "getTableApplicableColumn" should "return a List of columns used in payments table" in {
    paymentsCardTopology.getTableApplicableColumn("transactions").length should be(5)
  }

  it should "throw exception when table is not valid" in {
    an[ApplicableColumnsNotDefined] should be thrownBy {
      paymentsCardTopology.getTableApplicableColumn("invalid_table")
    }
  }

  it should "contain resolve all update required fields" in {
    noException should be thrownBy {
      paymentsCardTopology.checkUpdateRequiredTables.foreach { table =>
        paymentsCardTopology.getTableApplicableColumn(table)
      }
    }
  }

  "resolveToStandardOpType" should "resolve to standard optype notations" in {
    paymentsCardTopology.resolveToStandardOpType("c") should be("insert")
    paymentsCardTopology.resolveToStandardOpType("u") should be("update")
    paymentsCardTopology.resolveToStandardOpType("d") should be("delete")
  }

  it should "throw exception if optype cannot be resolved to standard notation" in {
    an[InvalidOpTypeException] should be thrownBy {
      paymentsCardTopology.resolveToStandardOpType("")
    }
  }
}
