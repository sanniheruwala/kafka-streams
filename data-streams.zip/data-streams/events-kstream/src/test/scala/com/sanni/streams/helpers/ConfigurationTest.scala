package com.sanni.streams.helpers

import com.sanni.streams.config.{ApplicationConfig, BaseApplicationConfig, KafkaConfig, PaymentsCardApplicationConfig}
import com.sanni.streams.UnitTests
import com.sanni.streams.config.{BaseApplicationConfig, KafkaConfig, PaymentsCardApplicationConfig}
import com.sanni.streams.constants.App
import com.sanni.streams.exceptions.{ConfigFileMissingException, InvalidConfigException}

class ConfigurationTest extends UnitTests {

  "Config Loader" should "throw missing file exception when config file doesn't exists" in {
    assertThrows[ConfigFileMissingException] {
      Configuration.load("test", "invalid_file.conf")
    }
  }

  it should "return a config Object with all configs present in file" in {
    val config = Configuration.load("test", App.PAYMENTS_CARD_STREAM_JOB_CONF_FILE)
    config.getString("kafka.application-id") should equal("payment_card_transformation")
  }

  it should "throw InvalidConfigException when the case class defined is incompatible" in {
    import pureconfig.generic.auto._
    case class UnParsableConfig(
        kafka: KafkaConfig,
        dummy_key: String
    ) extends BaseApplicationConfig(kafka)
    an[InvalidConfigException] should be thrownBy {
      Configuration.app[UnParsableConfig]("test", App.PAYMENTS_CARD_STREAM_JOB_CONF_FILE)
    }
  }

  it should "load config to case class" in {
    import pureconfig.generic.auto._
    val config = Configuration
      .app[PaymentsCardApplicationConfig]("test", App.PAYMENTS_CARD_STREAM_JOB_CONF_FILE)
    config shouldBe a[PaymentsCardApplicationConfig]
    config.kafka.applicationId should equal("payment_card_transformation")
  }
}
