package com.sanni.streams

import com.sanni.streams.helpers.JsonUtil
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord, RecordMetadata}

import scala.io.Source
import com.sanni.streams.bootstrap.Bootstrap
import com.sanni.streams.config.ApplicationConfig
import com.sanni.streams.constants.App
import com.sanni.streams.helpers.{Configuration, JsonUtil}
import com.sanni.streams.models.Event

object GenerateData extends App with Bootstrap {

  import pureconfig.generic.auto._
  override val appConfig = Configuration.app[ApplicationConfig](env, App.DEFAULT_APP_CONFIG_FILE_NAME)

  private val properties = appConfig.kafkaConfig.getTopologyProperties()
  properties.put(
    "key.serializer",
    "org.apache.kafka.common.serialization.StringSerializer"
  )
  properties.put(
    "value.serializer",
    "org.apache.kafka.common.serialization.StringSerializer"
  )

  val jsonString = Source.fromResource("producer_data_1.json").mkString
  val records = JsonUtil.fromJson[Array[TestRecord]](jsonString)
  var producer = new KafkaProducer[String, String](properties)

  //Send Records
  for (elem <- records) {
    val value = JsonUtil.toJson(elem.value)
    println(elem.key + " , " + elem.topic + " , " + value)
    val record = new ProducerRecord[String, String](elem.topic, elem.key, value)
    producer.send(
      record,
      (r: RecordMetadata, e: Exception) => {
        if (e != null) {
          System.out.println("Error producing to topic " + r.topic)
          e.printStackTrace()
        }
      }
    )
  }

  // add shutdown hook
  Runtime.getRuntime.addShutdownHook(new Thread() {

    override def run(): Unit = {
      System.out.println("Shutting Down")
      if (producer != null) producer.close
    }
  })
}

case class TestRecord(key: String, topic: String, value: Event)
