# data-streams
Data Streaming Layer(Non Spark Applications).
