Entity Processor
=

This module streams entity data from Kafka which is produced by [Maxwell](../maxwell) and then:
1. Converts the incoming JSON data to Avro.
2. Converts Avro to Parquet.
3. Stores the Parquet files into S3.
4. Merge these Parquet files (containing near realtime data) with historical data.

Documents
-

- [Data Ingestion](https://drive.google.com/open?id=1X6HTOk4LsPpNFzC4ihE6NtVAgJ_lsOCUdzrKVMiidno) -
For realtime ingestion.
- [Qubole POC Full Data Store](https://drive.google.com/open?id=1mHwxK_EfYoz2aqXAZRRDf0uHVja3b_HZBxTbOf0UG7k) -
This is our current batch ingestion pipeline. It is not relevant at a code-level but explains
how the ingestion via Qubole (external system) works currently for our different DBs like
API, Scrooge, Auth, Reporting, etc.

Setup
-

Setting up is straight-forward. It is important to note here that, this JAR does a bunch
of things which will run as separate jobs during deployment. So effectively while running
them on stage/prod, we'll specify appropriate "main" class names in the `java` command.

For each job, we'll have a separate step in our build/deployment pipeline.

```bash
$ mvn clean package
$ java -cp target/entity-processor-1.0-SNAPSHOT-jar-with-dependencies.jar CLASS_NAME
```

Want to quickly run it in Scala repl ?

```bash
$ scala -cp target/entity-processor-1.0-SNAPSHOT-jar-with-dependencies.jar
```

Using Docker ?

We're not using Docker in dev for Java/Scala apps currently. But if you decide to go this route
and make apt changes in [Dockerfile](./Dockerfile) and [entrypoint.sh](dockerconf/entrypoint.sh),
then please do make the necessary changes in this section.

Wiki
-

The [wiki page](https://github.com/razorpay/datahub/wiki/Event-Streaming) has a lot of information
around deployment of this module, table creation, optimisations, etc. It is highly recommended that
you read it.
