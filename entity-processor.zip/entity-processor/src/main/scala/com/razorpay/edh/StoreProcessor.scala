package com.razorpay.edh

import org.apache.kafka.streams.processor.{Processor, ProcessorContext}

class StoreProcessor extends Processor[String, Map[String, Any]] {

  override def init(context: ProcessorContext): Unit = {
    // initialize
  }

  override def process(cards: String, payments: Map[String, Any]): Unit = {
    //email,created_date,contact
    val map = collection.mutable.Map("updated_at"->cards.split(",")(2))
    map += "email" -> payments("email").toString
    map += "created_date" -> payments("created_date").toString
    map += "contact" -> payments("contact").toString

    utils.insertDB(map,"output")
  }

  override def close(): Unit = {
    // Any code for clean up would go here.  This processor instance will not be used again after this call.
  }

}
