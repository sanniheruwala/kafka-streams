package com.razorpay.edh

import com.fasterxml.jackson.annotation.JsonInclude.Include
import com.fasterxml.jackson.databind.{DeserializationFeature, ObjectMapper}
import com.fasterxml.jackson.module.scala.{DefaultScalaModule, ScalaObjectMapper}
import org.apache.kafka.common
import org.apache.kafka.common.serialization.{Deserializer, Serde, Serializer}
import org.apache.kafka.streams.scala._
import org.apache.kafka.streams.scala.kstream.{Consumed, KStream, Produced}
import org.apache.kafka.streams.{KafkaStreams, StreamsConfig}

import java.sql.{Connection, DriverManager, ResultSet, Statement}
import java.util
import java.util.Properties
import java.util.concurrent.TimeUnit

case class dataM(
                  database: String,
                  table: String,
                  `type`: String,
                  ts: Long,
                  xid: Long,
                  xoffset: Long,
                  position: String,
                  primary_key_columns: Option[Array[String]],
                  data: Map[String, Any],
                  old: Option[Map[String, Any]])

case class sample(database: String, table: String, `type`: String)

object KstreamPOC extends App {

  val mapper = new ObjectMapper() with ScalaObjectMapper
  mapper.registerModule(DefaultScalaModule)
  mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
  mapper.setSerializationInclusion(Include.NON_NULL)
  mapper.setSerializationInclusion(Include.NON_ABSENT)

  class KafkaBytesSerializer[T] extends Serializer[T] {
    override def configure(configs: util.Map[String, _], isKey: Boolean): Unit = 0

    override def serialize(topic: String, data: T): Array[Byte] = {
      mapper.writeValueAsBytes(data)
    }

    override def close(): Unit = 0
  }

  class KafkaBytesDeserializer[T >: Null <: Any : Manifest] extends Deserializer[T] {
    override def configure(configs: util.Map[String, _], isKey: Boolean): Unit = ()

    override def close(): Unit = ()

    override def deserialize(topic: String, data: Array[Byte]): T = {
      if (data == null) {
        return null
      } else {
        mapper.readValue[T](data)
      }
    }
  }

  def ConnectDB(cards_id: String): String = {
    val url = "jdbc:mysql://localhost/lookup"
    val username = "root"
    val password = "password"

    Class.forName("com.mysql.jdbc.Driver")
    val dbc: Connection = DriverManager.getConnection(url, username, password)
    dbc.setAutoCommit(false)
    val st: Statement = dbc.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)
    val rs = st.executeQuery(f"SELECT * from cards where id='${cards_id}'")
    var info = ""
    while (rs.next()) {
      info = rs.getString("iin")+","+rs.getString("country")+","+ rs.getString("updated_at")
    }
    dbc.close()
    info
  }

  val dataSerDe: Serde[dataM] =
    common.serialization.Serdes.serdeFrom(new KafkaBytesSerializer[dataM], new KafkaBytesDeserializer[dataM])

  val props: Properties = {
    val p = new Properties()
    p.put(StreamsConfig.APPLICATION_ID_CONFIG, "Kstream-application")
    p.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9093")
    p.put("enable.auto.commit", "true")
    p
  }

  val builder: StreamsBuilder = new StreamsBuilder

  builder
    .stream[String, dataM]("internal_test_api")(Consumed.`with`(Serdes.String, dataSerDe))
    .map((_, p) => (p.table, p.data))
    .filter((k, _) => k == "payments")
    .map((_, p) => (ConnectDB(p("card_id").toString), p))
//    .process(() => new StoreProcessor())
    .to("payments_transformed")(Produced.`with`(Serdes.String, Serdes.String))

  val streams: KafkaStreams = new KafkaStreams(builder.build(), props)
  streams.start()

  sys.ShutdownHookThread {
    streams.close(10, TimeUnit.SECONDS)
  }
}

