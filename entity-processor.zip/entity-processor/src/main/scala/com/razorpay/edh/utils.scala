package com.razorpay.edh

import java.sql.{Connection, DriverManager, ResultSet, Statement}

object utils {

  def insertDB(values: collection.mutable.Map[String, String], table: String): Unit = {
    val url = "jdbc:mysql://localhost/api"
    val username = "root"
    val password = "password"

    Class.forName("com.mysql.jdbc.Driver")
    val dbc: Connection = DriverManager.getConnection(url, username, password)
    val st: Statement = dbc.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)
    val data = values.values.toList.mkString("','")
    val query = f"insert into ${table} values('${data}')"
    st.executeUpdate(query)
    dbc.close()
    println("inserted successfully.")
  }

}
