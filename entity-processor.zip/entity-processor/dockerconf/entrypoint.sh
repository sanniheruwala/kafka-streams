#!/usr/bin/dumb-init /bin/sh
set -eux

cd /app

submit_spark_job()
{
    # Since we want the config file to be encrypted while uploading to S3, we are using sse to encrypt the
    # alohomora casted file while pushing to S3, which we can decrpyt later while getting the config from S3.
    local_jar_path="entity-processor/target/entity-processor-1.0-SNAPSHOT-jar-with-dependencies.jar"
    jar_s3_url="s3://${ENTITY_PROCESSOR_BUCKET}/application-jars/${APP_MODE}/${DEPLOYMENT_TYPE}/"
    config_s3_base_path="s3://${CONFIG_BUCKET}/entity-processor-config/${DEPLOYMENT_TYPE}/"
    config_s3_url="${config_s3_base_path}${APP_MODE}/application.conf.vault"
    deployment_config_file_path="entity-processor/src/main/resources/${DEPLOYMENT_TYPE}.application.conf.j2"
    alohomora_cast_file_path="entity-processor/src/main/resources/${DEPLOYMENT_TYPE}.application.conf"

    driver_memory="16G"
    if [[ "${APP_MODE}" == "stage" ]]; then
      driver_memory="4G"
    fi
    job_type=${JOB_TYPE}
    job_id=${DATABRICKS_JOB_ID}
    main_class="com.razorpay.edh.EntityProcessor"
    spark_options=""
    job_argument="--config_path ${config_s3_base_path}"
    # Now, based on the app type, specify the main class to be used while submitting the spark job
    if [[ "${job_type}" == "entity-processor" ]]; then
        main_class="com.razorpay.edh.EntityProcessor"
        topic_file_path="${TOPIC_FILE_BASE_PATH}/${DEPLOYMENT_TYPE}.txt"
        job_argument="${job_argument} --file_path ${topic_file_path}"
        if [[ "${APP_MODE}" == "prod" && "${DEPLOYMENT_TYPE}" == "api" ]]; then
          spark_options="--conf spark.executor.instances=6 --conf spark.dynamicAllocation.maxExecutors=12"
        elif [[ "${APP_MODE}" == "prod" && "${DEPLOYMENT_TYPE}" == "thirdwatch" ]]; then
          driver_memory="8G"
        fi
    elif [[ "${job_type}" == "hudi-batch-merger" ]]; then
        main_class="com.razorpay.edh.EntityBatchProcessor"
        job_type="entity-processor"
        job_argument="${job_argument} --table_list_file ${BACKFILL_FILE} --memory ${BATCH_JOB_MEMORY}"
        job_id=${DATABRICKS_BATCH_JOB_ID}
    elif [[ "${job_type}" == "hudi-files-copy" ]]; then
        main_class="com.razorpay.edh.HudiLatestFileCopier"
        # We cannot run entity_processor, hudi-batch-merger, hudi-files-copy simultaneously
        # So by overwriting job_type, we instruct datum module to kill already running job
        # and run the new one. That way only one job will be running at a time
        job_type="entity-processor"
        job_argument="${job_argument} --table_list_file ${BACKFILL_FILE}"
    fi

    if [[ "${job_type}" == "avro-schema-generator" ]]; then
        jar_s3_url="s3://${ENTITY_PROCESSOR_BUCKET}/application-jars/${APP_MODE}/${job_type}/"
    else
        jar_s3_url="${jar_s3_url}${job_type}/"
        job_type="${job_type}-${DEPLOYMENT_TYPE}"
    fi
    full_jar_s3_url="${jar_s3_url}entity-processor-1.0-SNAPSHOT-jar-with-dependencies.jar"

    aws s3 cp --acl "bucket-owner-full-control" ${local_jar_path} ${jar_s3_url}

    # x has to be disabled so that DATUM_AUTH_TOKEN and ssec_key don't get logged
    set +x

    ALOHOMORA_BIN=$(which alohomora)
    $ALOHOMORA_BIN cast --region ap-south-1 --env ${APP_MODE} --app datahub ${deployment_config_file_path}

    credstash_table="credstash-${APP_MODE}-datahub"

    # Key used for server side encryption while uploading to S3
    ssec_key=$(credstash -t ${credstash_table} -r ap-south-1 get s3_c_key)

    aws s3 cp --acl "bucket-owner-full-control" --sse-c --sse-c-key ${ssec_key} ${alohomora_cast_file_path} ${config_s3_url}

    # Submit the Job to Qubole via Datum
    if [[ "${DEPLOY_PLATFORM}" == "qubole" ]]; then
	    curl  -i \
	        -X POST \
	        -H "X-AUTH-TOKEN: ${DATUM_AUTH_TOKEN}" \
	        -H "Content-Type: application/json" \
	        -H "Accept: application/json" \
	        -d "{\"main_class\": \"${main_class}\", \"jar_path\": \"${full_jar_s3_url}\", \"label\": \"${CLUSTER_LABEL}\", \"app_name\": \"${job_type}\", \"kill_previous_job\": true, \"driver_memory\": \"${driver_memory}\", \"spark_options\": \"${spark_options}\", \"job_argument\": \"${job_argument}\" }" \
	        ${JOB_SUBMIT_URL}
    elif [[ "${DEPLOY_PLATFORM}" == "databricks" ]]; then
           # Submit the Job to databricks via Datum
      curl  -i \
          -X POST \
          -H "X-AUTH-TOKEN: ${DATUM_AUTH_TOKEN}" \
          -H "Content-Type: application/json" \
          -H "Accept: application/json" \
          -d "{\"job_id\": ${job_id}, \"command_type\": \"jar\", \"platform\": \"databricks\", \"app_name\": \"${job_type}\", \"kill_previous_job\": true, \"job_argument\": \"${job_argument}\"}" \
          ${JOB_SUBMIT_URL_DATABRICKS}
    fi

    set -x
}

# Do the basic initialization and get the app type
if [[ "${APP_MODE}" != "dev" ]]
then
    submit_spark_job
fi
